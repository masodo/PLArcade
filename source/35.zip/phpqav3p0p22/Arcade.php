<?php
session_start();
if($_GET['captcha']){
$im = imagecreatefrompng("captchabg.png");
$textcolor = imagecolorallocate($im, 333,333, 333);
imagestring($im, 4,rand(0,240), rand(0,20), "{$_SESSION['captcha']}", $textcolor);
imagepng ($im);
imagedestroy($im);
header("Content-type: image/jpeg");
imagepng($im);
die();
}

$key=htmlspecialchars($_COOKIE['PHPSESSID'], ENT_QUOTES);

function vsess() {
global $key;
if($key != $_REQUEST['akey']) { die("Authorization Mismatch"); }
}

if($_GET['do']=="verifyscore") {
print "&randchar=1&randchar2=2&savescore=1&blah=OK";
  die();
}

if($_GET['play']) {
setcookie(gname, $_GET['play']);
}
//-----------------------------------------------------------------------------------/
//  phpQuickArcade v3.0 � Jcink 2005-2009 quickarcade.jcink.com                        
//
//  Version: 3.0.22 Final. Released: June 1, 2009
//-----------------------------------------------------------------------------------/
// Thanks to (Sean) http://seanj.jcink.com 
// for: Tournies, JS, and more
// ---------------------------------------------------------------------------------/
ob_start();
if($_GET['cparea'] == "settings"&&$_POST['SettingsUpdate']) header("Location: ?cparea=settings");
if ($_GET['play']&&is_numeric($_GET['tournament'])) setcookie("phpqa_tourney",$_GET['tournament']);
$mtime=explode(" ",microtime());
require("./arcade_conf.php");
if($notinstalled) die("<a href='install.php'>Begin installation</a>");
$datestamp=$settings['datestamp'];
$smilies = file("emotes_faces.txt");
$smiliesp = file("emotes_pics.txt");
$csmile=count($smilies);
$modcpcheck=$acpcheck='ok';

function is_email($text){ 
$g=explode("@", $text);
if(count($g)==2) return true;
}

function after_decimal($i,$l){
$t=explode(".",$i);
$r=$t[0];
if ($t[1]) $r.=".".substr($t[1],0,$l);
return $r;
}

function ordsuf($num){ 
if (strlen($num)>1) $long=true; 
$f=substr($num,-1); 
if ($long&&$f=="0"||$long&&substr($num,-2,1)=="1"||substr($num,-1,1)>3) return $num."th"; elseif ($f=="1") return $num."st"; elseif ($f=="2") return $num."nd"; elseif($f==3) return $num."rd";
}

function displayemotes() { 
$smilies = file("emotes_faces.txt");
$smiliesp = file("emotes_pics.txt");
for($x=1;$x<count($smilies);$x++) {
$trim = rtrim($smilies[$x]);
$g.= "<img src=\"emoticons/$smiliesp[$x]\" onclick=\"document.forms['postbox'].elements['senttext'].value=document.forms['postbox'].elements['senttext'].value+&#39;$trim&#39;\"> ";
}
return $g;
}



function run_query($sql=false, $no_inj_protect=""){
static $queries=Array();
if ($sql) $queries[]=$sql;

// Inject protection, filters queries to stop injections
// don't want it / need something here? Then set the flag to 1.

$sql=eregi_replace("--", "", $sql);


if(!$no_inj_protect) {
$sql=eregi_replace("UNION", "", $sql);
$sql=eregi_replace("concat", "", $sql);
$sql=eregi_replace("pass", "", $sql);
}

if($sql !="") $r_q=mysql_query($sql);
$h=htmlspecialchars(mysql_error(), ENT_QUOTES);
if($h) { 
$sql=htmlspecialchars($sql, ENT_QUOTES);	
echo "<script language='Javascript'>
alert('Database Error: $h');
alert('Query used: $sql');
</script>"; 
}
return $sql?$r_q:$queries;
}


if (isset($_GET['id'])) $id = htmlspecialchars($_GET['id'], ENT_QUOTES);
if (isset($_GET['user'])) $user = htmlspecialchars ($_GET['user'], ENT_QUOTES);

if ($_GET['cat']&&!is_numeric($_GET['cat'])) die();

if ($_GET['action']=="logout") {
setcookie("phpqa_user_c",FALSE,time()-1);
setcookie("phpqa_user_p",FALSE,time()-1);
header("Location: ?");
}
$ipa = $_SERVER['REMOTE_ADDR'];
$phpqa_user_cookie = htmlspecialchars($_COOKIE['phpqa_user_c'], ENT_QUOTES);
$phpqa_user_p = htmlspecialchars($_COOKIE['phpqa_user_p'], ENT_QUOTES);
$senttext = htmlspecialchars($_POST['senttext'], ENT_QUOTES);

function message($info) {
echo "<div align='center'><div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Message</td><tr><td class=arcade1 valign=top><div align=center>$info</div></td></table></div><br>";
}

$connect = @mysql_connect($host,$username,$password);
$selection = @mysql_select_db($mysqldatabase);
$h=mysql_error();
if (!$connect || !$selection) { 
echo "There was an error with the database. A detailed report of the error is available below.<br /><br /><textarea cols=70 rows=20>$h</textarea><br /><br />You should check your password and database details. If you find that they are correct, but your <br />arcade is still not functioning please contact your hosting provider."; 
die();
}

/*   Tournament Stuff  */

if ($_COOKIE['phpqa_tourney']){

if (!$_GET['play']&&(($_GET['id']||$_GET['do'])&&!$_POST)||!is_numeric($_COOKIE['phpqa_tourney'])||!mysql_num_rows(run_query("SELECT id FROM phpqa_tournaments WHERE user='$phpqa_user_cookie' AND tournament_id='".$_COOKIE['phpqa_tourney']."'"))) {

setcookie("phpqa_tourney",false);$_COOKIE['phpqa_tourney']=false;}


}

if($_GET['play'] && !$_GET['tournament']) {

setcookie("phpqa_tourney",FALSE,time()-1);

}

/* End Tournament Stuff */

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// 	Rather than do 10 million checks, this check is run always 
//	at the top of the page.
//	Never take this out or move this!
//                   NEVER!
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$exist='';
if (isset($_COOKIE['phpqa_user_c'])) { // Is the username cookie set...

$query = run_query("SELECT * FROM phpqa_accounts WHERE name='$phpqa_user_cookie'");
$exist = mysql_fetch_array($query);
$acct_setting = explode("|", $exist[8]);



if($settings['override_userprefs']) $acct_setting='';
if (!$exist) die("You are now logged out. This has occurred due to a username/password mismatch. <a href='Arcade.php?action=logout'>Click here to reset.</a>.");


if (rtrim($exist[2]) != $_COOKIE['phpqa_user_p']) { // Compare passwords - it does exist 
echo "You are now logged out. This has occurred due to a username/password mismatch. <a href='Arcade.php?action=logout'>Click here</a>.";
die();
}
}

if ($exist['group']=="Moderator" || $exist['group']=="Admin") {
if(!$_GET['modcparea']) {
require("acpmoderate.php");
}
}


// Over Ride The Admins Default Setting.
$num_pages_of=$settings['num_pages_of'];
if ($acct_setting[2] != 0) {
$num_pages_of=$acct_setting[2];
}

if (!is_numeric($num_pages_of)) { $num_pages_of=10; }

if(isset($_GET['limit'])) $limit = $_GET['limit'];
if(isset($_GET['show'])) $show = $_GET['show'];

// ---------------------------
// Get for Pages
// ---------------------------
$sw = $_GET['show'];
$page = $_GET['page'];
if ($page<1) $page=1;
$pgn = $page + 1; 
$pgnm = $page - 1;

// ---------------------------
// Get for the LIMIT
// ---------------------------
$lim = $_GET['limit'];
$limn = $limit + $num_pages_of; 
$limnm = $limit - $num_pages_of; 
// ---------------------------

// ---------------------------
// Get for the SHOW
// ---------------------------
$sw = $_GET['show'];
$swn = $show + $num_pages_of; 
$swnm = $show - $num_pages_of; 
// ---------------------------

// ---------------------------
// get READY to go! OOOH 
// We're gonna rock! ROCK! ROCK!
// JCINK IS A ROCKA!
// ---------------------------

if (!$limit) { // No limit?
$limit=0;
}

if ( !is_numeric($limit) ) {
die();
}

if (!$show) {
$show=$num_pages_of;
}

if ( !is_numeric($show) ) {
die();
}

if ($_GET["action"] == "login") {

if($_GET['recovery']) {
$userID = htmlspecialchars($_GET['userID'], ENT_QUOTES);
$pword = htmlspecialchars($_GET['pword'], ENT_QUOTES);
} else {
$userID = htmlspecialchars($_POST['userID'], ENT_QUOTES);
$pword = htmlspecialchars($_POST['pword'], ENT_QUOTES);
}

$query = run_query("SELECT * FROM phpqa_accounts WHERE name='$userID'");
$exist = mysql_fetch_array($query);

if ($exist) { 	// M&Ms commercial - He DOES exist! D'Ooh
$thepassword_in_db = md5(sha1($pword));
if($_GET['recovery']) $thepassword_in_db = $pword;

if (rtrim($exist[2]) == $thepassword_in_db) {

if(!$_POST['cookiescheck']) {

setcookie("phpqa_user_c", "$exist[1]");
setcookie('phpqa_user_p', $thepassword_in_db, 0, ""."; HttpOnly");

} else {

setcookie("phpqa_user_c", "{$exist[1]}", time()+99999);
setcookie('phpqa_user_p', $thepassword_in_db, time()+99999, ""."; HttpOnly");

}

header("Location: Arcade.php");
} else {
echo "Sorry, the password you entered for the account, <b>$userID</b> is incorrect. Please try again.<br /><br /><a href='Arcade.php?action=forgotpass'>Forgot Password?</a>";
die();
}




} else {


echo "Sorry, that username, <b>$name</b>  doesn't appear to exist. Please go back and try again<br /><br />Did you mistype it? Are you <a href='Arcade.php?action=register'>Registered?</a><br /><br /><a href='Arcade.php?action=forgotpass'>Forgot Password?</a>";
die();

}


}

//check
if ($exist[7] =="") { 
$pic="Default"; 
} else { 
$pic=$exist[7]; 
} 

if(file_exists("./skins/$pic/crown1.gif")){
$crowndir="./skins/$pic";
} else {
$crowndir="./skins/Default/";
}
//end
?>

<title> <?php echo $settings[arcade_title]; ?> </title>
<link rel='stylesheet' type='text/css' href='./skins/<?php echo $pic; ?>.css'>
<?php
if($settings['enable_logo']) {
echo "<div align='center'><img src='arcade/pics/$pic.gif'></div>";
}


?>

<style type='text/css'>
// Design (C) Jcink
// HTML Cleanup by Seanj.jcink.com
// Javascript Features by seanj.jcink.com

.highscore td{
text-align:center;
}
td.challengename{
white-space:nowrap;
}
.viewedtimes{
float:right;
}
</style>
<script type='text/javascript'>
function chsize(n){
a=document.getElementsByTagName('object')[0]
b=document.getElementsByTagName('embed')[0]
if (!b) b=new Image()
if (!a) a=new Image()
amount=prompt('Change the '+n+':',eval("a."+n));
if (!amount) amount=eval("a."+n)
eval("a."+n+"=b."+n+"=amount;a."+n+"=b."+n+"=amount;")
return amount
}
function tog(a){
c=document.getElementsByTagName('div')
for(x=0;x<c.length;x++) {
if (c[x].getAttribute('name')!="tog_collect") continue;
n=c[x].style
if (c[x].id!=a) {n.display='none'; continue;}
if (n.display) n.display=''; else n.display='none';
}
}
</script>

<?php
if($_GET['action']=="emotes") {
echo "<div class='tableborder' width='75%'><table width='100%' cellpadding='4' cellspacing='1'><tr><td width='60%' align='center' class='headertableblock'>Emote</td><td width='60%' align='center' class='headertableblock'>Symbol</td></tr><tr>";

for($x=1;$x<count($smilies);$x++) {

$trim = htmlspecialchars(trim($smilies[$x]),ENT_QUOTES);

echo "\n<tr onclick=\"window.opener.document.forms['boxform'].elements['senttext'].value+='$trim'\"><td class='arcade1' align='left'><img src=\"emoticons/$smiliesp[$x]\"><br /></td><td class='arcade1' align='center'>$trim</td></tr>";



}

echo "</table></div>";
die();


}

function rangecheck($a){
if (substr($a,-1)!=".") $a.=".";
$ip=$_SERVER['REMOTE_ADDR'];
return substr($ip,0,strlen($a))==$a;
}

if($exist['group']=="Banned") { message("You have been banned from this arcade.");
die();
}
$bannedfile = file("banned.txt"); 
foreach($bannedfile as $a_banned_ip) {
if (rangecheck($a_banned_ip)) { 
message("You have been banned from this arcade.");
die();
}
} 
?>

<br />
<div align='center'>
<div class='tableborder'>
<table width='100%' cellpadding='4' cellspacing='1'>
<tr>
<?php 
if ($settings['show_stats_table']) { 
if ($acct_setting[3] !="No") {
?>

<td width='12%' align='center' class='headertableblock'>New Games</td>
<td width='50%' align='center' class='headertableblock'>Latest Scores</td>
<td width='10%' align='center' class='headertableblock'>Top Players</td>
<?php 
} else {
echo "<td width='10%' align='center' class='headertableblock'>Welcome to The Arcade</td>";
}

} else { ?>
<td width='10%' align='center' class='headertableblock'>Welcome to The Arcade</td>
<?php } ?>
</tr>
<tr>
<td class='arcade1' colspan='3' align='left'>
</td>
</tr>
<tr>
<?php
if (!$_GET['pplay']) {
if ($settings['show_stats_table']) {
if ($acct_setting[3] !="No") {
?>

<td class='arcade1' valign='top' align='left'>
<?php
$newgames = run_query("SELECT gameid,game,id FROM phpqa_games ORDER by id DESC LIMIT 0,7");
	while($g=mysql_fetch_array($newgames)){ 
echo "<img height='20' width='20' src='arcade/pics/$g[0].gif' alt='$g[1]' /><a href=\"Arcade.php?play=$g[0]\">$g[1]</a><br />";
}
?>
</td>
<td class='arcade1' valign='top' align='center'>
<table><td align='left'>
<?php

	$selectfrom = run_query("SELECT * FROM phpqa_scores ORDER BY phpdate DESC LIMIT 0,5");

	while($s=mysql_fetch_array($selectfrom)){ 

$parse_stamp = gmdate($datestamp, $s[5]+3600*$settings['timezone']);
echo "<a href='Arcade.php?action=profile&amp;user=$s[1]'>$s[1]</a></i> scored <i>$s[2]</i> in <a href='Arcade.php?id=$s[6]'><i>$s[7]</i></a> on $parse_stamp<hr>";
}
?>


</td></table>

</td>

<td class='arcade1' valign='top' nowrap='nowrap' align='left'>
<?php
$scoreboard = run_query("SELECT phpqa_accounts.name, COUNT(phpqa_leaderboard.username) AS champions FROM phpqa_accounts
LEFT JOIN phpqa_leaderboard ON phpqa_accounts.name = phpqa_leaderboard.username
GROUP BY phpqa_leaderboard.username
ORDER BY champions DESC LIMIT 0,10");
while($scores=mysql_fetch_array($scoreboard)){ 
echo"<a href='Arcade.php?action=profile&amp;user=".$scores['name']."'><i>".$scores['name']."</i></a>(".$scores['champions']." Wins)<br />";
}

} // End acct based check for big table
} // End check for big table
} // end play check
?>
</td>
</tr><tr>
<td colspan='3' class='arcade1' align='center'>
<?php
if (!isset($_COOKIE['phpqa_user_c'])) {
?>
[ Logged off: <a href='javascript:tog("login_form")'>Login</a> | <a href='Arcade.php?action=register'>Register</a> ] &middot; <a href='Arcade.php?action=leaderboards'>Leaderboard</a> &middot; <a href='javascript:tog("search");'>Search</a> &middot; <a href='Arcade.php?action=members'>Members</a>
<div style='display:none' id='login_form' name='tog_collect'><br /><br /><br /><form method='post' action='?action=login'> Name: <input type='text' name="userID" style='font-size: 80%;' /> <font style='font-size: 80%;'></font> Pass: <input type='password' name='pword' style='font-size: 80%;' /> <input type='submit' value='Login' style='font-size: 80%;' /><br /><font style='font-size: 80%;'> Remember?:</font><input type='checkbox' name='cookiescheck' /><a href='Arcade.php?action=register'><font style='font-size: 80%;'>No Account? Register to play!</font></a></form></div>
<?php
} else {

$checkChamps = mysql_num_rows(run_query("SELECT username FROM phpqa_leaderboard WHERE username = '$phpqa_user_cookie'"));

echo "Logged in: <A href='Arcade.php?action=profile&amp;user=$phpqa_user_cookie'>$phpqa_user_cookie</a> &middot; Total Wins: $checkChamps [<A href='Arcade.php?action=settings'>Settings</a>";
if ($exist['group']=="Admin") {
echo "&middot; (<a href='Arcade.php?cparea=idx'><b>Admin CP</b></a>) &middot; (<a href='Arcade.php?modcparea=idx'><b>Mod CP</b></a>)";
}
if ($exist['group']=="Moderator") {
echo "&middot; (<a href='Arcade.php?modcparea=idx'><b>Mod CP</b></a>)";
}
echo" &middot; <a href='Arcade.php?fav=1'>Favorites</a> &middot; <a href='Arcade.php?action=leaderboards'>Leaderboard</a> &middot; <a href='javascript:tog(\"search\")'>Search</a> &middot; <a href='Arcade.php?action=members'>Members</a> &middot; <a href='Arcade.php?action=tournaments'>Tournaments</a> &middot; <a href='Arcade.php?action=logout'>Log Out</a>]";

}
?>
<div style='display:none' id='search' name='tog_collect'><br /><br /><br /><form method='get'>Term: <input type='text' name='search' /><br />Search By: <select name='by'><? foreach(Array('game'=>'Game Name','gameid'=>'Game ID','about'=>'Game desc','Champion_name'=>'Champion Name') as $k=>$v) echo "<option value='$k'>$v</option>";?></select><br />In Category: <select size="1" name="searchcat"><option value='All' selected="selected">All</option><? $catquery=run_query("SELECT * FROM phpqa_cats");while ($catlist= mysql_fetch_array($catquery)) echo  "<option value='$catlist[0]'>$catlist[1]</option>"; ?></select><br /><input type='submit' value='search' name='action' /></form></div>
<?


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//				JShoutBox
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if (isset($_COOKIE['phpqa_user_c'])) {
if (isset($_POST['submitter2'])) {
if($exist[group] != "Validating") {
if ($_POST['senttext'] != "") {
vsess();
run_query("INSERT INTO `phpqa_shoutbox` (`name`,`shout`,`ipa`) VALUES ('$phpqa_user_cookie','$senttext','$ipa')", 1);
}
}

}
}

?>
</td></tr></table>
</div>
<br />
<?php 
if($settings['enable_shoutbox']) {
if ($acct_setting[1] !="No") {
?>
<div class='tableborder'>
<table width='100%' cellpadding='4' cellspacing='1'>
<tr>
<td width='5%' align='center' class='headertableblock' colspan='2' >Shoutbox</td>
</tr>
<tr>
<td class='arcade1' width='15%' align='left'><form action="" method='post' name='boxform'><input type='hidden' name='sb' value='1'><input type='hidden' name='akey' value='<?php echo $key; ?>'><input type='hidden' name="usersarcadename" class='Shoutbox' size='10'  value="<?php echo $phpqa_user_cookie; ?>" readonly="readonly" />Message:  <br /><input type='text' name='senttext' class='Shoutbox' size='15' /> <br /><input type='submit' value='Shout' name='submitter2' /> <input type='button' value='Refresh' onclick="window.top.location=window.top.location" /><br />[ <a href="javascript:window.open('Arcade.php?action=emotes', 'Emoticons', 'width=400,height=400,directories=no,location=no,menubar=no,resizable=no,scrollbars=yes,status=no,toolbar=no');void(0);">Emoticons</a> ]<br />
</form>
</td><td class="arcade1" width="50%">
<div id='scroll3' style="width:100%;height:140px;overflow:auto;overflow-x:hidden" align="left">
<?php
if(!$_GET['shoutbox']) {
	$selectfrom = run_query("SELECT name,shout,id,ipa FROM phpqa_shoutbox ORDER BY id DESC LIMIT 0,$num_pages_of");
} else {
	$selectfrom = run_query("SELECT name,shout,id,ipa FROM phpqa_shoutbox ORDER BY id DESC LIMIT $limit,$show");
}

	$shouttotal = mysql_fetch_array(run_query("SHOW TABLE STATUS LIKE 'phpqa_shoutbox'"));

echo "<div align='center'>";
if(!$_GET['arcade']) { 
if ($limit > 0) {
echo "<a href='Arcade.php?cat=$cat&amp;limit=$limnm&amp;show=$num_pages_of&amp;page=$pgnm&shoutbox=1'>Previous Page ($pgnm)</a> ";
}

}


echo ":: Total Shouts: $shouttotal[Rows] :: ";

if(!$_GET['arcade']) {
 
if ($shouttotal['Rows'] >= $limn&&$shouttotal['Rows'] != $limn) {
if (!$cat) {
echo "<a href='Arcade.php?limit=$limn&amp;show=$num_pages_of&amp;page=$pgn&shoutbox=1'>Next Page ($pgn)</a>"; 
} else  {
echo "<a href='Arcade.php?cat=$cat&amp;limit=$limn&amp;show=$num_pages_of&amp;page=$pgn&shoutbox=1'>Next Page ($pgn)</a>"; 
}
}

} else {
echo "<a href='Arcade.php'>View Pages</a>";
}

echo "<hr></div>";

if($shouttotal['Rows'] > 0) {

$badwords= file("badwords.txt");
$tb=count($badwords);

while($f=@mysql_fetch_array($selectfrom)) $dataa[]=$f;
if($dataa == "") die();
foreach($dataa as $vv) $userss[]=$vv[0];
$userss=array_flip(array_flip($userss));
$qqq=run_query("SELECT name,avatar FROM phpqa_accounts WHERE name='".implode($userss,"' OR name='")."'");
while($ggg=mysql_fetch_array($qqq)) { 
$avatars[$ggg[name]]="$ggg[avatar]";
}

foreach($dataa as $qashoutbox){
$postsofsomething = $qashoutbox[1];
$i=-1;
while ($i <= $csmile) {
$i++;
$postsofsomething = str_replace(rtrim($smilies[$i]), "<img 
src='emoticons/$smiliesp[$i]'>", $postsofsomething);
}

for($gx=-1;$gx<$tb;$gx++) {
if($badwords[$gx] != "") {
$postsofsomething= eregi_replace(rtrim($badwords[$gx]), "@!&^*%", $postsofsomething);
} 
}


if ($exist['group']=="Moderator" || $exist['group']=="Admin") {

echo "<a href='javascript:if (confirm(\"Are you sure?\")) document.location=\"Arcade.php?shoutdel=$qashoutbox[2]&akey=$key\"'>[x]</a><a href=\"?modcparea=IPscan&serv=$qashoutbox[3]\">[?]</a> ";

}

$qashoutbox[4]=$avatars[$qashoutbox[0]];

 echo "<u><b><a href='?action=profile&user=$qashoutbox[0]'".($qashoutbox[4]?" onmouseover=\"s=document.getElementById('shoutboxpopup');s.style.display='';s.getElementsByTagName('img')[0].src='".$qashoutbox[4]."';\" onmousemove=\"s=document.getElementById('shoutboxpopup').style;s.top=document.body.scrollTop+2+event.clientY;s.left=document.body.scrollLeft+event.clientX;\" onmouseout=\"document.getElementById('shoutboxpopup').style.display='none'":"")."\">$qashoutbox[0]</a></b></u>: $postsofsomething<br /><hr />";
}

}

 ?>
</div>
<div style='position:absolute;display:none' id='shoutboxpopup'><img /></div>
</td>
</tr>
</table>
</div>
<?php }} ?>
<br />
<?php
$c=@mysql_data_seek($catquery,0);

if($c) {
 echo "<div class='tableborder'><table><tr>";
while ($c = mysql_fetch_array($catquery)) {

echo  "<td width='5%' align='center' class='arcade1'><a href='Arcade.php?cat=$c[0]'>$c[1]</a></td>";
} 
echo"</tr></table></div>";
echo "<br />";
}
?>

<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1' align='left'>
<?php


echo "<a href='Arcade.php'>Arcade Home</a> &#187; ";
if ( $_GET['play'] ) { // Ok, you are playing.

echo "<b>Playing Game.</b>";

} elseif ( $_GET['id'] ) { // Now you're viewing the highscores

echo "<b>Viewing Highscore Tables.</b>";

} elseif ( $_GET['action'] == "register") { 

echo "<b>Registering!</b>";

} elseif ( $_GET['action'] == "members") {

echo "Viewing Member List";

} elseif ( $_GET['action'] == "leaderboards") { // At the leaderboards

echo "<b>Viewing Leaders</b>";

} elseif ( $_GET['cparea']) {

$cparea_info='';

$cparea_info['tar_import']="*.tar import new games";
$cparea_info['addgames']="Add new games";
$cparea_info['idx']="Index";
$cparea_info['cats']="Categories";
$cparea_info['emoticons']="Emoticons";
$cparea_info['mysql']="MySQL Toolbox";
$cparea_info['members']="Member Manager";
$cparea_info['Cheating_Attempts']="Cheating Attempts";
$cparea_info['settings']="Settings";
$cparea_info['Email']="Post Office";
$cparea_info['filter']="Word Filters";
$cparea_info['skin']="Skin Control";
$cparea_info['editor']="Modifying CSS";

$_GET['cparea']=htmlspecialchars($_GET['cparea']);

echo "<b><a href='Arcade.php?cparea=idx'>Arcade AdminCP</a> &#187; <a href='Arcade.php?cparea={$_GET['cparea']}'>{$cparea_info[$_GET['cparea']]}</a></b>";

} elseif ( $_GET['action']=="profile" ) {

echo "<b>Viewing Member Profile</b>";

} elseif ($_GET['action']=="tournaments") {
echo "<a href='Arcade.php?action=tournaments'>Tournament Index (Last 50)</a> [<a href='Arcade.php?action=tournaments&showall=1'>Show All</a>]"; if ($_GET['tid']) echo " &#187; Viewing Tournament Status";

} else { // Ok. You seem to be in arcade index then.

if($_GET['shoutbox']) $limit=0;
if($_GET['shoutbox']) $show=$num_pages_of;


// Favorite games
// Yep, that's all there is to it.
$fav_quer='';
if($_GET['fav']){
$favs=$acct_setting[5];
$buildfavs=explode(",", $favs);
foreach($buildfavs as $k=>$v) {
$v=htmlspecialchars($v, ENT_QUOTES);
$favslist.="'$v', ";
}
$favslist = substr($favslist, 0, -2);    
$fav_quer="WHERE gameid IN($favslist)";
}

$countquer = run_query("SELECT gamecat FROM phpqa_games $fav_quer".($_GET['cat']?" WHERE gamecat='".$_GET['cat']."'":""));

// Patch - 06/01/09
if($_GET['search']){
	$_GET['search']=htmlspecialchars($_GET['search'], ENT_QUOTES);
}

if($_GET['searchcat'] != "All" && $_GET['searchcat']){
	$_GET['searchcat']=intval($_GET['searchcat']);
}

// Patch - 04/20/2009
if($_GET['by'] || $_GET['by'] =="") {
if($_GET['by'] != "game" || $_GET['by'] !="gameid" || $_GET['by'] !="about" || 
$_GET['by'] !="Champion_name" || $_GET['by']=="") {
$_GET['by']='game';
}
}


$catquer = run_query("(SELECT gameid,game,about,Champion_name,Champion_score, times_played FROM phpqa_games ORDER BY rand() LIMIT 1) UNION ALL (SELECT gameid,game,about,Champion_name,Champion_score,times_played FROM phpqa_games $fav_quer".($_GET['cat']&&$_GET['action']!="search"?"WHERE gamecat='".$_GET['cat']."' ":"").($_GET['action']=="search"?"WHERE ".($_GET['searchcat']!="All"?"gamecat='".$_GET['searchcat']."' AND ":"").$_GET['by']." LIKE '%".$_GET['search']."%' ":"")."ORDER BY id DESC".($_GET['action']!="search"?" LIMIT $limit,$show":"").")", 1);

$arcadetotalcat = mysql_num_rows($countquer);

$f=@mysql_fetch_array($catquer);

echo "Viewing Arcade Index</td><td class='arcade1' style='width:1px'><a href='?play=".$f[0]."'>Random&nbsp;Game</a>";

}
echo "</td></tr></table></div>";

?>
<br />

<?php
if ($_GET['play']) { // Playing?


$play = htmlspecialchars($_GET['play'], ENT_QUOTES);

	$g = mysql_fetch_array(run_query("SELECT game,about,gameheight,gamewidth,gameid,Champion_name,Champion_score,remotelink,times_played FROM phpqa_games WHERE gameid='$play'")); 

	// Patch - 06/01/09
	if($g['game'] == "")  { 
	message("This game doesn't exist / has been deleted."); 
	die(); 
	}

    run_query("UPDATE phpqa_games SET `times_played`=".++$g[8]." WHERE gameid='$play'");
?>
<br />

<div class='tableborder'>
<table width='100%' cellpadding='4' cellspacing='1'>
<tr>
<td width='80%' align='center' class='headertableblock'></td>
<td width='10%' align='center' class='headertableblock'>Top Score</td>
</tr>
<tr>
<td class='arcade1' valign='middle' align='center'>
<?php 

if (isset($_COOKIE['phpqa_user_c']) || $settings['allow_guests']) { 

if ($highscore[0]=="") $highscore[0] = "";
if ($highscore[1]=="") $highscore[1] = "------------";
if ($g[remotelink] == "") {
$swf_resource = "arcade/$play.swf";
} else {
$swf_resource = $g[remotelink];
}

$yourscore=mysql_fetch_row(run_query("SELECT thescore FROM phpqa_scores WHERE gameidname='$play' AND username='$phpqa_user_cookie'"));


$yourscore=$yourscore[0];
?>
<a name="game"></a>
<object classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 codebase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0 align=middle WIDTH=<?php echo $g[3]; ?> HEIGHT=<?php echo $g[2]; ?>> <param name='movie' value='<?php echo $swf_resource ?>' /><param name=quality value=high /> <param name=allowScriptAccess value=sameDomain /> <param name='menu' value='false' /> <embed src="<?php echo $swf_resource; ?>" quality=high pluginspage=http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash WIDTH=<?php echo $g[3]; ?> HEIGHT=<?php echo $g[2]; ?> menu='false' type=application/x-shockwave-flash align=middle /></object>

<?php if(!isset($_COOKIE['phpqa_user_c'])) { echo "<br />[ You are not logged in. Your score will not be saved. <a href='?action=register'>Register</a> to submit highscores. ]"; } ?>

</td>
<td class='arcade1' valign='top' align='center'>

<a href='Arcade.php?play=<?php echo $play; ?>'><img alt='image' border='0' src='arcade/pics/<?php echo $play; ?>.gif' /></a>
<br />
<div id='popup' style='position:absolute;left:0px;top:0px;border:1px solid #333;background-color:#DDD;color:#888;display:none;width:150px;'>
<center><b>Highscores</b></center><br />
<ol style="text-align:left">
<?


$q=run_query("SELECT username,thescore FROM phpqa_scores WHERE gameidname='$play' ORDER BY thescore DESC LIMIT 0,10");


while($f=mysql_fetch_array($q)) echo "<li><b>".$f[0]."</b>: ".$f[1]."</li>";

?>
</ol></div>
</b><br /><b><?php echo $g[5]; ?></b><br /><?php echo $g[6]; ?><br /><? echo $yourscore!=$g[6]&&$yourscore?"Your Best: $yourscore<br />":""; ?><a href='Arcade.php?id=<?php echo $play ?>' onmouseover='document.getElementById("popup").style.display=""' onmouseout="document.getElementById('popup').style.display='none'" onmousemove="s=document.getElementById('popup').style;s.top=document.body.scrollTop+event.clientY+2;s.left=document.body.scrollLeft+event.clientX-152;">View Highscores</a><br /><br />Width: <a href="javascript:void(0)" onclick="this.innerHTML=chsize('width');" title='Change...'><?=$g[3]; ?></a><br />Height: <a href="javascript:void(0)" onclick="this.innerHTML=chsize('height')" title='Change...'><?=$g[2]; ?></a>

<?php 
} else { 

echo "You must be logged in to play the arcade games. Register an account to play - it's free <a href='Arcade.php?action=register'>Click here</a>!</td><td class='arcade1' valign='top' align='center'>";
}
?>

</td>

</tr>
</table>
</div>
<br />

<?php
} else if ($_GET['action'] == "forgotpass") {

?>

<?php
if($settings[enable_passrecovery]) {

if ($_POST['sendto_user']) {

if ($_POST['sendto_email'] == "") { 
message("You forgot to type in an email.");
die();
}

if ($_POST['sendto_user'] == "") { 
message("You left the username line blank.");
die();
}

$u=htmlspecialchars($_POST['sendto_user']);

$getmailuser = @mysql_fetch_array(run_query("SELECT name,pass,email FROM phpqa_accounts WHERE name='$u'", 1));

if (!$getmailuser) { 
message("The user, $u is not registered here."); 
die();
}



if (strtolower($_POST['sendto_email']) != strtolower($getmailuser['email'])) {

message("The email on file for $u, does not match the email you inputted. Please try again.");

die();
} else {
// Send the email now...

$SiteDomain = "http://".htmlspecialchars($_SERVER[HTTP_HOST]).htmlspecialchars($_SERVER[PHP_SELF])."?action=login&userID=$getmailuser[0]&pword=$getmailuser[1]&recovery=1";

$hd="admin@{$_SERVER[HTTP_HOST]}";
$members = $getmailuser['email'];
$mailsub = "Password Recovery From $settings[arcade_title]";
$mailbody = "Dear $u, \n\r\n\r\n\r A password recovery attempt has been made on your account at the $settings[arcade_title]. If you did not request password recovery ( also known as forgot password form ). If you did not request password recovery, the IP address of the internet user who did this was $_SERVER[REMOTE_ADDR]. Please contact an admin at $settings[arcade_title] about this. \n\r\n\r\n\r Visit the link below to login to your account again: \n\r\r\n ----------------------------------------------- \n\r\n\r $SiteDomain \n\r\n\r-----------------------------------------------\n\r\n\r When you login, visit change password in your profile to setup a new password.";
$headers = "From: $hd\n\r";
$mailfail=@mail($members,$mailsub,$mailbody,$headers);


if($mailfail) { message("Password recovery email sent. You should recieve it in the next 5 minutes to an hour depending on the speed of the mail server."); } else { message("Failed to send the email."); }

}
}
?>

<div align='center'>
<div class='tableborder'><table width=100%% cellpadding='4' cellspacing='1'><td width=60%% align=center class=headertableblock>Send Password</td><tr>

<td class=arcade1 valign="top"><div align=center><form action='' method=post enctype="multipart/form-data" name="postbox">
<br>Your Arcade Username: <br><input type=text name=sendto_user value=''><br><br>

<br>Your Email: <br><input type=text name=sendto_email><br><br>
<br><br><input type=submit value='Request Password'></div>
 </td>
</table>
</div>
<br><br>
<?php
} else {
message("Sorry, password recovery is not enabled on this arcade.");
}
?>
<?php
} else if ($_GET['action'] == "members") {

$q=run_query("SELECT `name`,`group`,`skin` FROM phpqa_accounts ORDER BY name ASC");

echo "<table class='tableborder'><tr><td class='headertableblock'>Username</td><td class='headertableblock'>Group</td><td class='headertableblock'>Skin</td></tr>";
while ($f=mysql_fetch_array($q)) echo "<tr><td class='arcade1'><a href='?action=profile&amp;user=".$f[0]."'>".$f[0]."</a></td><td class='arcade1'>".$f[1]."</td><td class='arcade1'>".$f[2]."</td></tr>";
$total=mysql_num_rows($q);
echo "</table><br /><div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>Total Registered Members: $total</td></table></div><br />";

} else if ($_GET['action'] == "register") {

if ($_POST['usernamesign'] != "" && $_POST['postpassword'] !="") {

$name = htmlspecialchars($_POST['usernamesign'], ENT_QUOTES);
$pass = md5(sha1(htmlspecialchars($_POST['postpassword'])));
$email= htmlspecialchars($_POST['emailsign'], ENT_QUOTES);

// Banned usernames -.-
$banned_u=explode(",", $settings['banned_usernames']);
foreach($banned_u as $k=>$v) {
if(strtolower($v)==strtolower($name) || strtolower($v)==strtolower($email)) { message("Sorry, that username is banned."); 
die();
}
}

// Banned emails -.-
$banned_m=explode(",", $settings['banned_mails']);
foreach($banned_m as $k=>$v) {
if(strtolower($v)==strtolower($email)) { message("Sorry, that email is banned."); 
die();
}
}


$senttext = str_replace("'", "&amp;#39;", $senttext);
$query = run_query("SELECT * FROM phpqa_accounts WHERE name='$name' OR email='$email'");
$exist = @mysql_fetch_array($query);

if ($exist) { 	// M&Ms commcerial - He DOES exist! D'Ooh

if($name==$exist['name']) { message("Sorry, that username, <b>$name</b>  already exists. Please choose another."); }
if($email==$exist['email']) { message("Sorry, that email, <b>$email</b>  already exists on another account. Please choose another."); }


// Security code
} elseif($settings['use_seccode'] && $_SESSION['captcha'] != $_POST['capcode']) {

message("The security code entered was wrong. Please try again."); 

} elseif ($_POST['postpassword2'] != $_POST['postpassword']) {
message("The entered passwords do not match, please try again.");

} elseif ($_POST['agreed'] != "iagreed") {
message("You must agree to the Terms of use. Please check the box.");

} elseif(!is_email($email)) {
message("The email you entered was invalid.");
} else  {
$status='Member';
if($settings['enable_validation']) $status='Validating';
$s_settings='';
if($_POST['dont']) {
$s_settings='||||No|';
}

if($settings['enable_email_validation']){
$raw_password=rand(0,10).rand(0,10).rand(0,10).rand(0,10).rand(0,10).rand(0,10).rand(0,10).rand(0,10).rand(0,10);
$pass = md5(sha1($raw_password));
$hd="admin@{$_SERVER[HTTP_HOST]}";
$mailsub = "Message from $settings[arcade_title] - Validate your email.";
$mailbody = "Dear $name, \n\r\n\r\n\r Our records indicate that you have registered an account at {$settings[arcade_title]}. Your details are as follows: \n\r\n\r ----------------------------------------------- \n\r\n\r Username: $name \n\r\n\r Password: $raw_password \n\r\n\r -----------------------------------------------\n\r\n\r\n\r If you did not request this password change, please IGNORE and DELETE this
email immediately. \n\r\n\r\n\r IP address of user who signed up: {$_SERVER['REMOTE_ADDR']}";
$headers = "From: $hd\n";
@mail($email,$mailsub,$mailbody,$headers);
}

run_query("INSERT INTO `phpqa_accounts` (`name`,`pass`,`email`,`ipaddress`,`avatar`,`group`,`skin`,`settings`) VALUES ('$name','$pass','$email','$ipa','','$status','Default','$s_settings')", 1);

if(!$settings['enable_email_validation']) { 
	message("Welcome to the arcade, <b>$name</b>!<br /><br /> Click the '<i>Login</i>' link above, enter your name and password and login to begin playing!");
} else {
	message("Welcome to the arcade, <b>$name</b>! Please check your <b>e-mail</b>. This arcade requires that you validate your email address. <br /><br />You have been given a new password via email which you must use to login.");
}

if($settings['enable_validation']) message("Note: The Administrator has enabled <b>validation</b> on this arcade. This means that each account must be approved by the administrator to post messages, use settings, or the shoutbox. As a validating user you will not be able to submit your score yet so please be patient, thank you.");
}
}

if($settings['use_seccode']) {
$spam=rand(0,999999);
$_SESSION['captcha']=$spam;
}

if(!$settings['disable_reg']) {


?>
<form action='?action=register' method='POST'>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><td width='60%' align='center' class='headertableblock'>Register</td><td width='60%' align='center' class='headertableblock'></td><tr>

 <tr><td class="arcade1" align="left"><b>Enter a user name</b><br />Note: username cannot contain most special characters.</td><td class="arcade1" align="left"><input type='text' name='usernamesign' /></td></tr><tr><td class="arcade1" align="left"><b>Enter a password</b><br />Choose a secure password and dont make it your username or something easy to guess.</td><td class="arcade1" align="left"><input type="password" name="postpassword" value="" /></td></tr><tr><td class="arcade1" align="left"><b>Re-enter your password</b><br />Please re-enter your password exactly as it was above.</td><td class="arcade1" align="left"><input type="password" name="postpassword2" value="" /></td></tr><tr><td class="arcade1" align="left"><b>Email</b><br />Please enter your email.</td><td class="arcade1" align="left"><input type="text" name="emailsign" value="" /></td></tr>
 
 <?php if($settings['use_seccode']) { ?>
 <tr><td class="arcade1" align="left"><b>Your security code</b><br />If you do not see any numbers, or see a broken image, please contact the arcade administrator to repair the problem.</td><td class="arcade1" align="left"><img src="?captcha=1"></td></tr>
 <tr><td class="arcade1" align="left"><b>Confirm your security code</b><br />Please enter the code shown above in image format.
Note: Only numbers are permitted. A "0" is a numerical zero, not the alphabetical "O".</td><td class="arcade1" align="left"><input type="text" name="capcode" value="" /></td></tr>
<?php } ?>


 </div></td></table></div>
<br />

<div align='center'>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><td width=60% align=center class='headertableblock'>Terms of use</td><tr>

<td class='arcade1' valign="top"><div align=center>
Please read fully and check the 'I agree' box ONLY if you agree to the terms 
<br /><br />I agree to the Terms of use:<input type='checkbox' value='iagreed' name='agreed' /><br /><br />Please remember that we are not responsible for any messages posted. We do not vouch for or warrant the accuracy, completeness or usefulness of any message, and are not responsible for the contents of any message. The messages express the views of the author of the message, not necessarily the views of this arcade. Any user who feels that a posted message is objectionable is encouraged to contact us immediately by email. We have the ability to remove objectionable messages and we will make every effort to do so, within a reasonable time frame, if we determine that removal is necessary. You agree, through your use of this service, that you will not use this arcade to post any material which is knowingly false and/or defamatory, inaccurate, abusive, vulgar, hateful, harassing, obscene, profane, sexually oriented, threatening, invasive of a person's privacy, or otherwise violative of any law. You agree not to post any copyrighted material unless the copyright is owned by you or by this arcade. You also agree that you will not try to cheat the system to gain a highscore.<br /><br /><br />Disallow emails from this arcade? <input type='checkbox' name='dont'><br />If you do this, you won't recieve news and updates, and won't get emails when your highscores are taken.</div></div>
<tr><td class=headertableblock colspan='0'><div align='center'><input type='submit' name='post' value='Register Me!' /></div></td></tr>
</form>
 </td></table>
</div><br />
<?php
} else { message("Sorry, the admin has disabled new registrations for this arcade at this time. Please try again at a later date."); }

} elseif ($_GET['action'] == "profile") {

$profiledata=@mysql_fetch_array(run_query("SELECT * FROM phpqa_accounts WHERE name='$user'"));

$ggggg=explode("|",$profiledata['settings']);
if (!$profiledata) {

message("Error: No username with the name, <b>$user</b> exists");

} else {

$lq=run_query("SELECT `gameid`,`game`,`about`,`Champion_score` FROM phpqa_games WHERE Champion_name='$user'");

$q=run_query("SELECT count(id) FROM phpqa_shoutbox WHERE name='$user'");

?>

<div align='center'>
<div class='tableborder'>
<table width='100%' cellpadding='4' cellspacing='1'>
<tr><td width=60% align=center class='headertableblock'>Profile Data</td><td width=60% align=center class='headertableblock'>Setting</td></tr>
<tr><td class='arcade1' align='left'><b>Name</b><br /></td><td class='arcade1' align='left'><?php echo $user; ?></td></tr>
<tr><td class='arcade1' align='left'><b>Group</b></td><td class='arcade1' align='left'><?php echo $profiledata['group']; ?></td></tr>
<tr><td class='arcade1' align='left'><b>Skin</b><br /></td><td class='arcade1' align='left'>Default</td></tr>
<tr><td class='arcade1' align='left'><b>Total Shouts</b><br /></td><td class='arcade1' align='left'><?php echo mysql_result($q,0); ?></td></tr>
<tr><td class='arcade1' align='left'><b>Total Champions</b></td><td class='arcade1' align='left'><?php echo mysql_num_rows($lq); ?></td></tr>
<tr><td class='arcade1' align='left'><b>Tournaments Won</b></td><td class='arcade1' align='left'><?php echo mysql_result(run_query("SELECT tournaments FROM phpqa_accounts WHERE name='$user'"),0); ?></td></tr>
<tr><td class='arcade1' align='left'><b>Contact</b></td><td class='arcade1' align='left'>[ <?php 

if($ggggg[0] != No) { // F-ZERO LOL
echo $profiledata[email];
} else {
echo "Private";
}

?> ]</td></tr>
<? if ($profiledata[avatar]){ ?><tr><td class='arcade1' align='left'><b>Avatar</b><br /></td><td class='arcade1'><img src='<?php echo $profiledata[avatar] ?>'></td></tr><? } ?>
</table>
</div>
<br /> <br />
<?php


$scoreboardc = run_query("SELECT phpqa_accounts.name, COUNT(phpqa_leaderboard.username) AS champions FROM phpqa_accounts
LEFT JOIN phpqa_leaderboard ON phpqa_accounts.name = phpqa_leaderboard.username
GROUP BY phpqa_leaderboard.username
ORDER BY champions DESC LIMIT 0,10000");

$x=1;
while($checkpos=mysql_fetch_array($scoreboardc)){
if($_GET['user'] == "$checkpos[name]") {
 echo "<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'>";
 echo "<td width='2%' align=center class='headertableblock'>UsersName</td><td width='30%' align=center class='headertableblock'>";

if($x == "3" || $x == "2" || $x == "1") echo "<img alt='image' src='$crowndir/crown{$x}.gif' />";

echo "$user is ".ordsuf($x)." in the Arcade.";

if($x == "3" || $x == "2" || $x == "1") echo "<img alt='image' src='$crowndir/crown{$x}.gif' />";

echo "</td>";
echo "<tr><td class='arcade1'><div align='center'><i><A href=\"Arcade.php?action=profile&amp;user=".$checkpos['name']."\">".$checkpos['name']."</a></i></div></td><td class='arcade1'><div align='center'><I>".$checkpos['champions']."</I> wins</div></td></td></tr>";
echo "</table></div>";

 
} else {
$x++;
}


}



?>

<br /><br />



<div align='center'><div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><td width='100%' align='center' class='headertableblock' colspan='3'>Games that <?php echo $user; ?> is champion.</td><tr>

<?php

while($getstats=mysql_fetch_array($lq)){

?>
<tr>
<td class='arcade1' width=2%><img width='20' height='20' src='arcade/pics/<?php echo $getstats['gameid']; ?>.gif' /></td><td class='arcade1' align='left'><b><a href='Arcade.php?play=<?php echo $getstats['gameid']; ?>'><?php echo $getstats[game]; ?></a></b> - <?php echo $getstats[about]; ?></b><br /></td><td class='arcade1' width='20%' align='center'>Score to beat: <br /><b><?php echo $getstats['Champion_score']; ?></b></td>
<?php
}
?>
</tr></table></div><br /><br />

<?php
}

} elseif ($_GET['action'] == leaderboards) {

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Leaderboards
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

$scoreboard = run_query("SELECT phpqa_accounts.name, COUNT(phpqa_leaderboard.username) AS champions FROM phpqa_accounts
LEFT JOIN phpqa_leaderboard ON phpqa_accounts.name = phpqa_leaderboard.username
GROUP BY phpqa_leaderboard.username
ORDER BY champions DESC LIMIT 1,50000");

$scoreboardc = mysql_fetch_array(run_query("SELECT phpqa_accounts.name, COUNT(phpqa_leaderboard.username) AS champions FROM phpqa_accounts
LEFT JOIN phpqa_leaderboard ON phpqa_accounts.name = phpqa_leaderboard.username
GROUP BY phpqa_leaderboard.username
ORDER BY champions DESC LIMIT 0,3"));

 echo "<br /><div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'>";
 echo "<td width='2%' align=center class='headertableblock'>UsersName</td><td width='30%' align=center class='headertableblock'><img alt='image' src='$crowndir/crown1.gif' /> Arcade Champion with: <img image src='$crowndir/crown1.gif' /></td>";
echo "<tr><td class='arcade1'><div align='center'><i><A href=\"Arcade.php?action=profile&amp;user=".$scoreboardc['name']."\">".$scoreboardc['name']."</a></i></div></td><td class='arcade1'><div align='center'><I>".$scoreboardc['champions']."</I> wins</div></td></td></tr>";
echo "</table></div><br />";


 echo "<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'>";
 echo "<td width='2%' align=left class='headertableblock'>UsersName</td><td width='30%' align=center class='headertableblock'>Totals</td>";



while($scores=mysql_fetch_array($scoreboard)){ 

echo"<tr><td class='arcade1'><div align='center'><A href='Arcade.php?action=profile&amp;user=".$scores['name']."'>".$scores['name']."</a></div></td><td class='arcade1'><div align='center'>".$scores['champions']." wins</div></td></td></tr>";
}
echo "</table></div><br>";



// ~~ Start Tournament Leaders By: Jcink (Tournies Now: 1% Jcink 99% Sean) ~~

$scoreboard = run_query("SELECT name,tournaments FROM phpqa_accounts WHERE tournaments!=0 ORDER BY tournaments DESC LIMIT 1,51");

$scoreboard2 = mysql_Fetch_array(run_query("SELECT name,tournaments FROM phpqa_accounts ORDER BY tournaments DESC LIMIT 0,1"));


echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>Tournaments Leaderboards - Top 50 players.</td></table></div><br />";


 echo "<br /><div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'>";
 echo "<td width='2%' align=center class='headertableblock'>UsersName</td><td width='30%' align=center class='headertableblock'><img alt='image' src='$crowndir/crown1.gif' /> Tournaments Champion with: <img image src='$crowndir/crown1.gif' /></td>";
echo "<tr><td class='arcade1'><div align='center'><i><A href=\"Arcade.php?action=profile&amp;user=".$scoreboard2['name']."\">".$scoreboard2['name']."</a></i></div></td><td class='arcade1'><div align='center'><I>".$scoreboard2['tournaments']."</I> wins</div></td></td></tr>";
echo "</table></div><br />";



 echo "<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'>";
 echo "<td width='2%' align=left class='headertableblock'>UsersName</td><td width='30%' align=center class='headertableblock'>Totals</td>";

while($scores=mysql_fetch_array($scoreboard)){ 

echo"<tr><td class='arcade1'><div align='center'><A href='Arcade.php?action=profile&amp;user=".$scores['name']."'>".$scores['name']."</a></div></td><td class='arcade1'><div align='center'>".$scores['tournaments']." wins</div></td></td></tr>";
}
echo "</table></div><br>";


// ~~ End   Tournament Leaders By: Jcink (Tournies Now: 10% Jcink 90% Sean) ~~



// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//		End Leaderboards
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
} elseif ($_GET['action'] == Online) {
?>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=30% align=center class=headertableblock>User</td><td width=40% align=center class=headertableblock>Last Refresh</td><td width=50% align=center class=headertableblock>Location</td>
<?php

$how='name';
if($_GET['method'] != "name") $how='time';

$online=run_query("SELECT * FROM phpqa_sessions ORDER by $how DESC");

while($g=mysql_fetch_array($online)){ 


if($g[location]=="") $g[location]="Viewing Arcade Index";


$parse_stamp = gmdate($datestamp, $g[time]+3600*$settings['timezone']);
echo "<tr><td class=arcade1><a href='?action=profile&user=$g[name]' title=''>$g[name]</a></td><td class=arcade1><div align=center>$parse_stamp</div></td><td class=arcade1>";

if (preg_match("/Playing Game/i", $g[location])) { 

$nameandid=explode("Playing Game: ", $g[location]);
$id=explode("|",$nameandid[1]);
echo "Playing Game: <a href='Arcade.php?play=$id[1]'>$id[0]</a>";

} else {

echo $g[location];

}


echo "</td></tr>";


}

?>
</td></tr></table></div><br />
<?php

} elseif ( $_GET['action'] == "tournaments") {
if (!$phpqa_user_cookie) die();
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//	       Arcade Tournaments/Challenges Engine
//              Coded By: http://seanj.jcink.com
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if(!$settings[enable_tournies]) {
message("The arcade admin has disabled the tournaments system.");
die();

}

if (is_numeric($_GET['tid'])){
$ie=strstr($_SERVER['HTTP_USER_AGENT'],"MSIE");
$q=run_query("SELECT * FROM phpqa_tournaments WHERE tournament_id='".$_GET['tid']."' ORDER BY id ASC");
$q2=run_query("SELECT phpqa_games.game,phpqa_tournaments.game_id,phpqa_tournaments.misc_settings,null,null,null,null,null,null FROM phpqa_games,phpqa_tournaments WHERE phpqa_tournaments.game_id=phpqa_games.gameid AND tournament_id='".$_GET['tid']."'");
$udata=false;
while($f=mysql_fetch_assoc($q)) {$data[]=$f;if ($f[user]==$phpqa_user_cookie) $udata=$f[times_played];}
$gameid=$data[0][game_id];
$gamedata=mysql_fetch_assoc($q2);
$attempts=array_pop(explode(",",$gamedata[misc_settings]));
$game=$gamedata[game];
$numplayers=$data[0][players];
function img($n){global $pic;return "<img width='20px' height='20px' src='skins/".(file_exists("skins/$pic/$n-bar.gif")?$pic:"Default")."/".$n."-bar.gif' border='0' />";}

//Calculating next #:
//prev#*2+1=next#
//ex:
//1*2+1=3
//3*2+1=7
//7*2+1=15, so next # is 15
$space=Array(0,1,3,7);
$table=Array();
$levels=log($numplayers,2)+1;
$real_players=0;
for($x=0;$x<$levels;$x++) {
$last=($x==$levels-1);
$y=0;
$xx=0;
foreach($data as $v) {
$xx++;
if ($xx>=(pow(2,$x)-1)+pow(2,$x)&&$x) {
if ($v[level]<$x) $players[]="------";
$xx=1;
}
if ($v[level]>=$x) {
$score=explode(" ",$v[average_score]);
$players[]=Array($v[user],$score[$x],$v[times_played],$v[level]);
if ($x==0) $real_players++;
$xx=0;
}
}
if ($last&&!$players[0]) $over=false; else $over=true;
$t=$x?$numplayers/pow(2,$x):$numplayers;
for($y=0;$y<$t;$y++) if (!$players[$y]) $players[$y]="------";
foreach($players as $k=>$v) if ($v[0]==$phpqa_user_cookie) $opponent=str_replace("-","",$players[($k+(($k+1)%2?1:-1))]);
for($y=0;$y<$space[$x];$y++) $table[$y].="<td></td>".($last?"":"<td></td>");
foreach($players as $k=>$v) {
$table[$y++].="<td class='challengename'>".($v!="------"?($last?"<img src='$crowndir/crown1.gif' /> ".$v[0]." <img src='skins/Default/crown1.gif' />":$v[0]." (".($v[3]>$x?$attempts:$v[2])."/$attempts): <b>".after_decimal($v[1],3)."</b>"):$v)."</td>".($last?"":"<td>".img($k%2?"ltu":"ltd")."</td>");
if ($k!=array_pop(array_keys($players))) for($z=0;$z<$space[$x+1];$z++) $table[$y++].="<td></td>".($last?"":"<td".($ie?" style='padding-left:1px'":"").">".($k%2?"":img(($z==floor($space[$x+1]/2)?"tri":"vert")))."</td>");
}
unset($players);
for($z=0;$z<$space[$x];$z++) $table[$y++].="<td></td>".($last?"":"<td></td>");
}
if ($_GET['join']) {
$q=mysql_fetch_array(run_query("SELECT id FROM phpqa_tournaments WHERE user='$phpqa_user_cookie' AND tournament_id='".$_GET['tid']."'"));
if ($q) message("You are already in this tournament."); else {
if ($numplayers<=$real_players) message("This Tournament is full"); else {
run_query("INSERT INTO phpqa_tournaments(tournament_id,user) VALUES('".$_GET['tid']."','$phpqa_user_cookie')");
message("Joined tournament Successfully. <a href='Arcade.php?action=tournaments&tid=".$_GET['tid']."'>Refresh</a>");
}
}
}
echo "<br />
<div align='center'><div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class='headertableblock'>$game Tournament: $numplayers Players</td><tr><td class='arcade1' valign='top' align='center'>

<table style='border-collapse:collapse;' cellpadding='0'>";
foreach($table as $v) echo "\n<tr>".$v."</tr>";
echo "
</table>
".(is_numeric($udata)&&!$over?"<br />".(!$opponent?"You dont have an opponent to go against.":($udata<$attempts?"You havent used up all of your turns yet. <a href='Arcade.php?play=$gameid&tournament=".$_GET['tid']."'>Play Now</a>":"You've used up all of your turns.")):($numplayers>$real_players?"<a href='Arcade.php?action=tournaments&tid=".$_GET['tid']."&join=1'>Join</a> This Tournament":""))."
<br /><br />

</td>
</tr>
</table></div>";
} elseif (is_numeric($_GET['submit'])&&$_GET['game']) {
$q=mysql_fetch_array(run_query("SELECT * FROM phpqa_tournaments WHERE user='$phpqa_user_cookie' AND tournament_id='".$_COOKIE['phpqa_tourney']."'"));
$attempts=array_pop(explode(",",mysql_result(run_query("SELECT misc_settings FROM phpqa_tournaments WHERE tournament_id='".$_COOKIE['phpqa_tourney']."'"),0)));
$left=($attempts-$q[times_played]);
$average=explode(" ",$q[average_score]);
if ($_GET['winner']) {$left=0;array_pop($average);}
echo "<div class='tableborder'><table width='100%'><tr><td class='arcade1' align='center'><br /><br /><br />Your score was: ".$_GET['submit']."<br />Your current ".($_GET['st']==1?"highest":"average")." score is: ".array_pop($average)."<br />You have $left Chance".($left==1?"":"s")." Left<br /><br />".($left&&!$_GET['winner']?"<a href='Arcade.php?play=".$_GET['game']."&tournament=".$_COOKIE['phpqa_tourney']."'>Play Again?</a><br />":"")."<a href='Arcade.php?action=tournaments&tid=".$_COOKIE['phpqa_tourney']."'>View Tournament Status</a><br /><br /><br /><br /></td></tr></table></div><br />";
} elseif ($_GET['create']) {
$players=Array(2,4,8);
if ($_POST['submit']) {
	vsess();
if (!in_array($_POST['players'],$players)) die("LoL Good thing I know JavaScript!");

// Patch - 04/20/2009
$_POST['gameid']=htmlspecialchars($_POST['gameid'], ENT_QUOTES);

if (!mysql_fetch_array(run_query("SELECT id FROM phpqa_games WHERE gameid='".$_POST['gameid']."'"))) die("Ha! Like I'd leave myself open to THAT one");
$max=mysql_result(run_query("SELECT MAX(tournament_id) FROM phpqa_tournaments"),0)+1;
foreach(Array('players','meth','attempts') as $v) if (!is_numeric($_POST[$v])) die();
$q=run_query("INSERT INTO phpqa_tournaments(tournament_id,user,players,game_id,misc_settings) VALUES($max,'$phpqa_user_cookie','".$_POST['players']."','".$_POST['gameid']."','".$_POST['meth'].",".$_POST['attempts']."')");
if (!$q) echo "ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ".mysql_error(); else echo "<div class='tableborder'><table width='100%'><tr><td class='arcade1' align='center'><br /><br /><b>Tournament Created</b><br /><br />View it <a href='Arcade.php?action=tournaments&tid=$max'>here</a><br /><br /><br /></td></tr></table></div>";
} else {
echo "<form method='post'><input type='hidden' name='akey' value='$key'><table class='tableborder'><tr><td class='arcade1'><center><h3>Create A Tournament</h3><br /><br /><table><tr><td>Game:</td><td><select name='gameid'>";
$q=run_query("SELECT game,gameid FROM phpqa_games ORDER BY game");
while($f=mysql_fetch_assoc($q)) echo "<option value='".$f[gameid]."'>".$f[game]."</option>";
echo "</select></td></tr><tr><td>Number of Players:</td><td><select name='players'>";
foreach($players as $v) echo "<option value='$v'>$v</option>";
echo "</select></td></tr><tr><td>Scoring Method:</td><td><select name='meth'><option value='0'>Average Score</option><option value='1'>Highest Score</option></select></td></tr><tr><td>Scoring Attempts:</td><td><select name='attempts'>";
for($x=1;$x<11;$x++) echo "<option value='$x'>$x</option>";
echo "</select></td></tr><tr><td colspan='2' align='center'><input type='submit' value='Create Tournament' name='submit' /></td></tr></table></td></table></form>";
}
} else {
$q=run_query("SELECT tournament_id,game_id,winner,players,misc_settings FROM phpqa_tournaments WHERE players IS NOT NULL GROUP BY tournament_id ORDER BY tournament_id DESC".(!$_GET['showall']?" LIMIT 0,50":""));
$q2=run_query("SELECT gameid,game FROM phpqa_games");
$q3=run_query("SELECT tournament_id,count(tournament_id) FROM phpqa_tournaments GROUP BY tournament_id");
$q4=run_query("SELECT tournament_id,times_played FROM phpqa_tournaments WHERE user='$phpqa_user_cookie'");
while($f=mysql_fetch_array($q4)) $tournaments_in[$f[0]]=$f[1];
while($f=mysql_fetch_array($q3)) $num_players[$f[0]]=$f[1];
while($f=mysql_fetch_array($q2)) $gamename[$f[0]]=$f[1];
echo "<table class='tableborder'><tr>";
foreach(Array('Game','Players','Open Spots','Status','Erase') as $v) {

if($v == Erase) {
if($exist['group']=="Moderator" || $exist['group']=="Admin") {
echo "<td class='headertableblock'>$v</td>";
}
} else  {
echo "<td class='headertableblock'>$v</td>";
}

}

while($f=mysql_fetch_assoc($q)) {

$attempts=array_pop(explode(",",$f[misc_settings]));
echo "<tr><td class='arcade1'><a href='Arcade.php?action=tournaments&tid=".$f[tournament_id]."'>".$gamename[$f[game_id]]."</a></td><td class='arcade1'>".$f[players]."</td><td class='arcade1'>".($f[players]-$num_players[$f[tournament_id]])."</td><td class='arcade1'>".($f[winner]?"Winner: ".$f[winner]:(isset($tournaments_in[$f[tournament_id]])?"Joined ".($tournaments_in[$f[tournament_id]]>=$attempts?"":"(<a href='Arcade.php?play=".$f[game_id]."&tournament=".$f[tournament_id]."'>Play</a>)"):($f[players]==$num_players[$f[tournament_id]]?"Full":"Open (<a href='Arcade.php?action=tournaments&tid=".$f['tournament_id']."&join=1'>Join</a>)")))."</td>";
if($exist['group']=="Moderator" || $exist['group']=="Admin") {
echo "<td class='arcade1'><a href='?action=tournaments&tourndel=$f[tournament_id]&akey=$key'>Delete</a></td>";
}
echo "</tr>";
}

echo "</table><br />";
echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'><a href='Arcade.php?action=tournaments&create=1'>Create</a> A Tournament</td></table></div><br />";


}
echo "<br />";

} elseif ( $_GET['action'] == "settings") {  

if (isset($_COOKIE['phpqa_user_c'])) {

if($exist[group] == "Validating") {

message("!ALERT!: Sorry, your account is still in validation. This means you cannot: submit your highscores, shout on the shoutbox, or edit your profile. Please wait for an admin to validate your account, then you'll be ready to play.");

die();

}

?>
<br>

<div align='center'>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=20% align=center class=headertableblock>Main Menu</td><td width=80% align=center class=headertableblock>Information</td><tr>

<td class=arcade1 align="left" valign="top">
<div class=headertableblock>Your Profile</div>
<br>
 -- <a href="Arcade.php?action=settings&p=newemail">Edit Email</a><br>
-- <a href="Arcade.php?action=settings&p=avatar">Edit Avatar</a><br>
<br>
<div class=headertableblock>Arcade Settings</div>
<br>
<?php 
if(!$settings['override_userprefs']) {
?>
-- <a href='Arcade.php?action=settings&p=display'>Preferences</a><br>
<?php
}
?>
-- <a href='Arcade.php?action=settings&p=skin'>Skin Chooser</a><br>
-- <a href='Arcade.php?action=settings&p=pass'>Change Password</a><br>
 </td>


<td class=arcade1 valign="top" align="left">

<?php

if ($_GET['action']=="settings" && $_GET['p']=="") {

echo "<div align='center'>Welcome to your arcade controls. Your last 10 scores:<hr>";

	$selectfrom = run_query("SELECT * FROM phpqa_scores WHERE username='$phpqa_user_cookie' ORDER BY phpdate DESC LIMIT 0,10");

while($s=mysql_fetch_array($selectfrom)){ 
$parse_stamp = gmdate($datestamp, $s[5]+3600*$settings['timezone']);
echo "<i>$s[2]</i> in <a href='Arcade.php?id=$s[6]'><i>$s[7]</i></a> on $parse_stamp <br />";
}
echo "</div>";

}

if ($_GET['p'] == "avatar") {
unset($problem);

$remoteavatar=htmlspecialchars($_POST['remoteavatar'], ENT_QUOTES);
$message=$remoteavatar;
$message=str_replace("#", "&#35;", $message);
$message=str_replace("&&#35;62;", "&#62;", $message); 
$message=str_replace("&&#35;60;", "&#60;", $message); 
$message  = htmlspecialchars($message, ENT_QUOTES);
$message=str_replace("javascript", "java&nbsp;script", $message);
if (strtolower(substr($remoteavatar,0,11))=="javascript:") { $problem.="Invalid characters in avatar URL"; }

if ($_POST['remoteavatar'] || $_FILES['remoteavatar']['name']) {
vsess();
// ---------------------
// Upload an avatar
// ---------------------
if($settings['upload_av_max_size']) {
if($_FILES['remoteavatar']['name']) { 
$message="./useravatars/".$exist['name'].".img";
$imgcontents=@file_get_contents($_FILES['remoteavatar']['tmp_name']);
if(!$imgcontents) $problem.="Failed to read file.<br />";
if(!@getimagesize($_FILES['remoteavatar']['tmp_name'])) $problem.="Invalid image file, or your webhost is not setup correctly to read images.<br />";
if(preg_match("/tEXtComment/i", $imgcontents)) $problem.="Image files with tEXTcomment not allowed.<br />";
if($_FILES['remoteavatar']['size'] > $settings['upload_av_max_size']) $problem.="The avatar is too large in file size to be uploaded.";
if(!$problem) $uploadavatar = @move_uploaded_file($_FILES['remoteavatar']['tmp_name'], $message);
if(!$uploadavatar) $problem.="Failed to upload your avatar to the server. Please contact the arcade administrator.";
}
}


if(!$problem) { 
	run_query("UPDATE `phpqa_accounts` SET `avatar` = '$message' WHERE name='$phpqa_user_cookie'"); 
	echo "Avatar Updated."; 
} else { 
	echo $problem; 
}

} else {
echo "<div align=center>Current Avatar:<br>";
if($exist[5] !="" ) { echo "<img src='$exist[5]'><br /><br />"; } else { echo "None<br /><br />"; }

// Remote avatar
echo "<form action='Arcade.php?action=settings&p=avatar' method='POST'>";
echo "<input type='hidden' name='akey' value='$key'>";
echo "Enter URL To Remote Avatar:<br>";
echo "<input type='text' name='remoteavatar' value='$exist[5]'>";
echo "<input type='submit' name='submit' value='Submit'></form>";

if($settings['upload_av_max_size']) {
//Upload avatar
echo "<form action='Arcade.php?action=settings&p=avatar' method='POST' enctype='multipart/form-data'>";
echo "<input type='hidden' name='akey' value='$key'>";
echo "Upload an avatar from your computer:<br>";
echo "<input type='file' name='remoteavatar'>";
echo "<input type='submit' name='submit' value='Submit'></form>";

echo "<br><form action='Arcade.php?action=settings&p=avatar' method='POST'><input type='hidden' name='akey' value='$key'><input type=hidden name='remoteavatar' value='blank.gif'><input type=submit value='Remove Avatar'></form>";
}

echo "<hr>";

echo "<form action='Arcade.php?action=settings&p=avatar' method='POST'>Gallery Choices:<br><br>";
echo "<input type='hidden' name='akey' value='$key'>";
echo '<select size="1" name="gallery">';
$dir = "./avatars/";
if (is_dir($dir)) {
   if ($dh = opendir($dir)) {
       while (($file = readdir($dh)) !== false) {
		   if ($file != ".." && $file != ".") {
           echo "<option value='$file'>$file</option>";
		   }
       }
       closedir($dh);
   }
}
echo "</select><input type='submit' name='submit' value='Go'></form>";
if ($_POST['gallery']) {
$gallery=$_POST['gallery'];
$gallery=str_replace("..", "", $gallery);
$dir = "./avatars/$gallery";
if (is_dir($dir)) {
	echo "<form action='Arcade.php?action=settings&p=avatar' method='POST'>";
	echo "<input type='hidden' name='akey' value='$key'>";
   if ($dh = opendir($dir)) {
$x=2;
       while (($file = readdir($dh)) !== false) {
		   if ($file != ".." && $file != ".") {
           echo " [<input type='radio' name='remoteavatar' value='avatars/$gallery/$file'>]<a href=\"javascript:document.getElementsByName('remoteavatar')[$x].checked='checked';void(0);\"><img src='avatars/$gallery/$file'></a> ";
                   $x++;
		   }
       }
closedir($dh);
echo "<br><br><input type=submit name='submit' value='Select'></form>";
   }}}}

} elseif($_GET['p']=="pass") {

if ($_POST['newpass']) {
if ($_POST['newpass'] != "") {
$UpDated = md5(sha1($_POST['newpass']));
vsess();
run_query("UPDATE `phpqa_accounts` SET `pass` = '$UpDated' WHERE name='$phpqa_user_cookie'", 1);
echo "Password updated. You must now login again.";
} else {
echo "You didn't enter a new password. Please go back and fill out the input box.";
}

} else {

echo '<form action="Arcade.php?action=settings&p=pass" method="POST">';
echo "<input type='hidden' name='akey' value='$key'>";
echo 'New Password: <input type="text" name="newpass">';
echo '<br><input type="submit" value="Change Password"></form>';

}

} elseif($_GET['p']=="newemail") {

if ($_POST['newemail']) {

if ($_POST['newemail'] != "") {

if(is_email($_POST['newemail'])) {

$UpDated = htmlspecialchars($_POST['newemail'], ENT_QUOTES);
vsess();
run_query("UPDATE `phpqa_accounts` SET `email` = '$UpDated' WHERE name='$phpqa_user_cookie'");

echo "Email updated.";

} else {

echo "Invalid email address.";

}

} else {

echo "You didn't enter a new email. Please go back and fill out the input box.";

}

} else {

echo '<form action="Arcade.php?action=settings&p=newemail" method="POST">';
echo "<input type='hidden' name='akey' value='$key'>";
echo "Your current email on file is: <b>$exist[3]</b>.<br><br>New Email: <input type=\"text\" name=\"newemail\">";
echo '<br><input type="submit" value="Change Email"></form>';

}


} elseif($_GET['p']=="display") {


if ($_POST['viewavatars']) {

$viewavatars = htmlspecialchars($_POST['viewavatars'], ENT_QUOTES);
$viewshoutbox = htmlspecialchars($_POST['viewshoutbox'], ENT_QUOTES); // ENT QUOTES EDDY ENT QUOTES AHUHUHUHUH
$numberofgamesperpage = htmlspecialchars($_POST['numberofgamesperpage'], ENT_QUOTES);
$viewtop = htmlspecialchars($_POST['viewtop'], ENT_QUOTES);
$allowmemoradmin = htmlspecialchars($_POST['allowmemoradmin'], ENT_QUOTES);
$timezone = htmlspecialchars($_POST['timezone'], ENT_QUOTES);

vsess();
run_query("UPDATE `phpqa_accounts` SET `settings` = '$viewavatars|$viewshoutbox|$numberofgamesperpage|$viewtop|$allowmemoradmin|$acct_setting[5]' WHERE name='$phpqa_user_cookie'");
echo "Settings updated! <a href='Arcade.php?action=settings&amp;p=display'>Reload</a> to see changes...";
} else {

echo '<form action="Arcade.php?action=settings&p=display" method="POST">';
echo "<input type='hidden' name='akey' value='$key'>";
//
// Show email?
//

echo "Show My email publicly in my profile?";
echo '<select size="1" name="viewavatars">';
if ($acct_setting[0] == "Yes") {
echo "<option value='Yes' selected>Yes</option>";
echo "<option value='No'>No</option>";
} else {
echo "<option value='No' selected>No</option>";
echo "<option value='Yes'>Yes</option>";
}
echo "</select><br>";

// 
// View Shoutbox
//
echo "View the Shoutbox?";
echo '<select size="1" name="viewshoutbox">';
if ($acct_setting[1] == "Yes") {
echo "<option value='Yes' selected>Yes</option>";
echo "<option value='No'>No</option>";
} else { 
echo "<option value='No' selected>No</option>";
echo "<option value='Yes'>Yes</option>";
}
echo "</select><br>";


// 
// Number of games per page?
//
echo "Games & Shouts per page?<br>";
echo "<input type='text' name='numberofgamesperpage' value='$acct_setting[2]' onblur='if (this.value!=parseFloat(this.value)) alert(\"Games per page must be a number.\")'><br>";

// 
// View Top Area
//

echo "View the Arcade header?";
echo '<select size="1" name="viewtop">';
if ($acct_setting[3] == "Yes") {
echo "<option value='Yes' selected>Yes</option>";
echo "<option value='No'>No</option>";
} else { 
echo "<option value='No' selected>No</option>";
echo "<option value='Yes'>Yes</option>";
}
echo "</select><br>";


echo "Allow other members/the admin to contact you by Email?";
echo '<select size="1" name="allowmemoradmin">';
if ($acct_setting[4] == "Yes") {
echo "<option value='Yes' selected>Yes</option>";
echo "<option value='No'>No</option>";
} else { 
echo "<option value='No' selected>No</option>";
echo "<option value='Yes'>Yes</option>";
}
echo "</select><br>";
?>
<br>
<br>
<input type='submit' name='' value='Update settings'>
<?php


echo '</form>';
}

} elseif ($_GET['p']=="skin") {

if ($_POST['skinsettings']) {
$updateskin=htmlspecialchars($_POST['updateskin'], ENT_QUOTES);
vsess();
run_query("UPDATE `phpqa_accounts` SET `skin` = '$updateskin' WHERE name='$phpqa_user_cookie'");
echo "Skin Updated";
} else {
echo '<form action="Arcade.php?action=settings&p=skin" method="POST">';
echo "<input type='hidden' name='akey' value='$key'>";
echo '<select size="1" name="updateskin" onchange="document.getElementsByTagName(\'link\')[0].href=\'skins/\'+this.value+\'.css\'">';
echo "<option value='$exist[7]'>Select Skin... ($exist[7])</option>";

  $handle = opendir("skins");
  while (false!==($topic=readdir($handle)))
   {
     if( $topic == '.' || $topic == '..' )
       continue;
       $forumtopiclist [basename($topic,".css")] = @filemtime($s."/".$topic);
     }
  arsort($forumtopiclist);
  foreach($forumtopiclist as $v=>$k) echo "<option value='$v'>$v</option>";
echo '</select><br /><br><br>';
echo "<input type=submit value='Update Skin' name='skinsettings'></form>"; 
}

}

?>
</td></div>
</table>
</div>
<br>
<?php
} else {
echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td width='80%' align='center' class='headertableblock'>Error</td></tr><tr><td width='80%' align='center' class='arcade1'>You cannot edit your profile while logged out. Please login.</td></tr></table></div>";
}

} else if ($id || $_GET['do'] == "newscore" || $_GET['autocom']) { 
 $thescore = $_POST['thescore'];
 if ($_GET['do'] == newscore) {
  $id=htmlspecialchars($_POST['gname'], ENT_QUOTES);
  $thescore = $_POST['gscore'];
 }

if ($_GET['autocom']) {

$id=htmlspecialchars($_COOKIE['gname'], ENT_QUOTES);
$thescore = $_POST['gscore'];

}

 // highscores. UpGraded. ^.<;;
 // Architect : Don't do that gay wink <_> 

 // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 //	Get highscores list of a game when on the id= page
 // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 $gameinfo = mysql_fetch_array(run_query("SELECT gameid,game,about,Champion_name,Champion_score,times_played FROM phpqa_games WHERE gameid = '$id'"));

 if (!$gameinfo) {
header("Location: index.php");
die();
 }
 ?>
 <div class='tableborder'>
 <table width='100%' cellpadding='4' cellspacing='1'>
 <tr>
 <td width='5%' align='center' class='headertableblock'></td>
 <td width='60%' align='center' class='headertableblock'><?php echo $gameinfo[game]; ?></td>
 <td width='20%' align='center' class='headertableblock'>Top Score</td>
 </tr>
 <tr>
 <td class='arcade1' valign='top'><a href='Arcade.php?play=<?php echo $id ?>'><img alt='image' border='0' src='arcade/pics/<?php echo $id ?>.gif' /></a><br /></td>
 <td class='arcade1' align='center'><?php echo $gameinfo[about]; ?><br /><br /><a href='Arcade.php?play=<?php echo $id ?>'>[Play]</a><div class='viewedtimes'><? echo "Played ".$gameinfo[times_played]." Time".($gameinfo[times_played]!=1?"s":""); ?></div></td>
 <td class='arcade1' valign='top' align='center'><img alt='image' src='<?php echo $crowndir; ?>/crown1.gif' /><br /><b><?php echo $gameinfo[Champion_name]?$gameinfo[Champion_name]:""; ?></b><br /><?php echo $gameinfo[Champion_score]?$gameinfo[Champion_score]:"-------------";  ?><br /><a href='Arcade.php?id=<?php echo $id; ?>'>View Highscores</a>
 </td>
 </tr>
 </table>
 </div>
 <br />
 <?php
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 			Score Submission
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($_COOKIE['phpqa_tourney']){
   if(!is_numeric($thescore)) die();
 
/*
 if($settings['use_cheat_protect']) {
   $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
   if($_GET['do']) $url=str_replace("index.php","Arcade.php", $url);
   
   $refer=explode("?", $_SERVER[HTTP_REFERER]);

   $_SERVER['HTTP_REFERER']=htmlspecialchars($_SERVER['HTTP_REFERER']);
   
   if($_SERVER['HTTP_REFERER'] != "") {
    if($refer[0] != $url) {
     message("Error: Your attempt to submit a highscore was detected as cheating.! NOTE: ! This does not necessarily mean you WERE cheating! A record of this event has been sent to the Admin(s) to verify your score.<br /><br />If you weren't cheating, the most common reason why your computer would be picked up by our cheating protect would be if your firewall settings are too high. For information about what to adjust for <a href='http://service1.symantec.com/SUPPORT/nip.nsf/735050b77b1fcece88256bc7005c3bc6/b9b47ad7eddd343b88256c6b006a85a8'>Norton Personal Firewall</a> click there. For other firewall please talk to your software vendor. Thank you.<br /><br /><br />But if you were cheating, the attempt has been logged and will be dealt with shortly ;)");
     run_query("INSERT INTO phpqa_logs (log_type,username,thescore,ip,comment,phpdate,gameidname,cheaturl) VALUES ('Cheating','$phpqa_user_cookie','$thescore','$ipa','','$time','$gameidname','$_SERVER[HTTP_REFERER]')");
     die();
    }
   }
  }
*/

 echo "<div class='tableborder'><table width='100%'><tr><td class='arcade1' align='center'><br /><br /><br />";
 $data=Array();
 $data[]=mysql_fetch_array(run_query("SELECT * FROM phpqa_tournaments WHERE tournament_id='".$_COOKIE['phpqa_tourney']."' AND user='$phpqa_user_cookie'"));
 $gamedata=mysql_fetch_array(run_query("SELECT * FROM phpqa_tournaments WHERE tournament_id='".$_COOKIE['phpqa_tourney']."' AND game_id IS NOT NULL"));
 $attempts=array_pop(explode(",",$gamedata[misc_settings]));
 $q=run_query("SELECT * FROM phpqa_tournaments WHERE tournament_id='".$_COOKIE['phpqa_tourney']."' ORDER BY id ASC");
 while($f=mysql_fetch_assoc($q)) $data[]=$f;
 $level=$player=array_shift($data);
 $player=Array($player[user],explode(" ",$player[average_score]),$player[times_played],$player[level]);
 if ($player[2]>=$attempts||!mysql_fetch_array(run_query("SELECT id FROM phpqa_tournaments WHERE tournament_id='".$_COOKIE['phpqa_tourney']."' AND game_id='$id'"))) $cheating=true;
 if (!$cheating){
  $level=$level['level'];
  $xx=0;
  $players=Array();
foreach($data as $v) {
if ($v[players]) $num_players=$v[players];
$xx++;
if ($xx>=1+pow(2,$player[3])&&$player[3]) {
if ($v[level]<$x) $players[]="";
$xx=1;
}
if ($v[level]>=$player[3]) {
$score=explode(" ",$v[average_score]);
$players[]=Array($v[user],$score[$player[3]],$v[times_played],$v[level]);
$xx=0;
}
}
  $gameid=$id;
  $id=$opponent=false;
  foreach($players as $k=>$v) if ($v[0]==$phpqa_user_cookie) $id=$k;
  $opponent=$players[($id+(($id+1)%2?1:-1))];
  if (!$opponent) echo "You dont have an opponent to go against...";
  else {
   //We're READY TO GO GO GO GO GO!
   $tmp=$player[1];
   $misc=explode(",",$gamedata[misc_settings]);
   if ($misc[0]=="1") {
   $lastscore=array_pop($tmp);
   $avg2=$avg=($lastscore>$thescore?$lastscore:$thescore);
   } else 
   $avg2=$avg=((array_pop($tmp)*$player[2])+$thescore)/($player[2]+1);
   $tmp[]=$avg;
   $avg=implode(" ",$tmp);
   $left=$attempts-($player[2]+1);
   $o=run_query("UPDATE phpqa_tournaments SET times_played=times_played+1,average_score='$avg' WHERE user='$phpqa_user_cookie' AND tournament_id='".$_COOKIE['phpqa_tourney']."'");   
if ($opponent[2]>=$misc[1]&&($player[2]+1)>=$misc[1]) {
    $user=${($avg2>$opponent[1])?"player":"opponent"};
    $userlevel=$user[3]+1;
    $user=$user[0];
    if ($userlevel==log($num_players,2)) {
     run_query("UPDATE phpqa_tournaments SET winner='$user' WHERE tournament_id='".$_COOKIE['phpqa_tourney']."' AND game_id IS NOT NULL");
     run_query("UPDATE phpqa_accounts SET tournaments=tournaments+1 WHERE name='$user'");
    }
    run_query("UPDATE phpqa_tournaments SET level=level+1,times_played=0,average_score=concat(average_score,' 0') WHERE user='$user' AND tournament_id='".$_COOKIE['phpqa_tourney']."'");
    if ($user==$phpqa_user_cookie) $winner=1;
   }
   header("Location: Arcade.php?action=tournaments&submit=$thescore&game=$gameid&winner=$winner&st=".$misc[0]);
  }
  } else {
   echo "You've already used all of your turns....";
 }
 echo "<br /><br /><br /><br /></td></tr></table></div><br />";
} else {
 if (isset($_COOKIE['phpqa_user_c'])) { // Only if the cookie is set....
  if ($_GET['c'] == 1 && !$_POST['sb']) { // Ah well, so what that anyone can edit their comment <_<
  vsess();
  run_query("UPDATE `phpqa_scores` SET `comment` = '$senttext' WHERE gameidname='$id' && username='$phpqa_user_cookie'"); 
}
 if($_GET['do'] || $_POST['thescore']) $commentthing =  "<form name='postbox' action='Arcade.php?id=$id&amp;c=1' method='POST'><input type='hidden' name='akey' value='$key'><div class='tableborder'><table width='100%'><td class='arcade1' width='100%' align='center'>Congratulations, new best score, your final score was: <b>$thescore</b>.<br /><br /><input type='text' name='senttext'><input type='submit' name='gocomment' value='Send Comment'></form><br/>".displayemotes()."</td></table></div><br /><br />";
  $time = time();
 $gameidname = $id;
  if ($thescore) {
   if(!is_numeric($thescore)) die();

 /*
  if($settings['use_cheat_protect']) {
   $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
   if($_GET['do']) $url=str_replace("index.php","Arcade.php", $url);
   $refer=explode("?", $_SERVER[HTTP_REFERER]);
   if($_SERVER['HTTP_REFERER'] != "") {
    if($refer[0] != $url) {
     message("Error: Your attempt to submit a highscore was detected as cheating.! NOTE: ! This does not necessarily mean you WERE cheating! A record of this event has been sent to the Admin(s) to verify your score.<br /><br />If you weren't cheating, the most common reason why your computer would be picked up by our cheating protect would be if your firewall settings are too high. For information about what to adjust for <a href='http://service1.symantec.com/SUPPORT/nip.nsf/735050b77b1fcece88256bc7005c3bc6/b9b47ad7eddd343b88256c6b006a85a8'>Norton Personal Firewall</a> click there. For other firewall please talk to your software vendor. Thank you.<br /><br /><br />But if you were cheating, the attempt has been logged and will be dealt with shortly.");
     run_query("INSERT INTO phpqa_logs (log_type,username,thescore,ip,comment,phpdate,gameidname,cheaturl) VALUES ('Cheating','$phpqa_user_cookie','$thescore','$ipa','','$time','$gameidname','$_SERVER[HTTP_REFERER]')");
     die();
    }
   }
  }
*/
   
   if($exist[group] == "Validating") {
   echo "<div class='tableborder'><table width='100%'><td class='arcade1' width='100%' align='center'>Your score score was: <b>$thescore</b>... <br /><br /></td></table></div><br /><br />";
   message("!ALERT!: Sorry, your account is still in validation. This means you cannot: submit your highscores, shout on the shoutbox, or edit your profile. Please wait for an admin to validate your account, then you'll be ready to play.");
   die();
   }
   $checkTOPscore = @mysql_fetch_array(run_query("SELECT * FROM phpqa_scores WHERE gameidname='$id' ORDER BY thescore DESC LIMIT 0,1"));
   $checkscore = @mysql_fetch_array(run_query("SELECT * FROM phpqa_scores WHERE gameidname='$id' && username='$phpqa_user_cookie' ORDER BY thescore DESC"));
   if ($checkscore) { // a score already exists by this person.
    if ($checkscore["thescore"] < $thescore) { // if checkscore is greater than thescore....
    //UpDated!
     run_query("UPDATE `phpqa_scores` SET `thescore` = '$thescore', `gamename` = '$gameinfo[game]', `phpdate` = '$time',`ip` = '$ipa' WHERE gameidname='$id' && username='$phpqa_user_cookie'");
     if($settings['allow_comments']) echo $commentthing;

  } else {
    echo "<div class='tableborder'><table width='100%'><td class='arcade1' width='100%' align='center'>Your score score was: <b>$thescore</b>...";
   echo "<br /><br />Try again.</td></table></div><br /><br />";
   }

 } else {
  // First time, submit it in.
   run_query("INSERT INTO phpqa_scores (username,thescore,ip,comment,phpdate,gameidname,gamename) VALUES ('$phpqa_user_cookie','$thescore','$ipa','','$time','$gameidname','$gameinfo[game]')");
  if($settings['allow_comments']) echo $commentthing;
 }

 if ($thescore > $checkTOPscore[2]) { // We have a champion!

// ---------------
// Email the loser
// ---------------
if($settings['email_scores']) {
if($checkTOPscore['username'] !="") {
$person_to_mail=mysql_fetch_array(run_query("SELECT email,settings FROM phpqa_accounts WHERE name='".$checkTOPscore['username']."'"));
$psettings = explode("|", $person_to_mail['settings']);
if($psettings[4] != "No" && $person_to_mail['email'] !=$exist['email']) { 
$SiteDomain = "http://".htmlspecialchars($_SERVER[HTTP_HOST]).htmlspecialchars($_SERVER[PHP_SELF])."?id={$gameidname}";
$hd="admin@{$_SERVER[HTTP_HOST]}";
$mailsub = "Message from $settings[arcade_title] - Top {$gameinfo[game]} score defeated!";
$mailbody = "Dear {$checkTOPscore['username']}, \n\r\n\r\n\r Oh no! Someone has taken your top score for the game {$gameinfo[game]} at {$settings[arcade_title]}! Get back in there and take your score! \n\r\n\r Visit the link below view the scoreboard for {$gameinfo[game]}: \n\r\n\r ----------------------------------------------- \n\r\n\r $SiteDomain \n\r\n\r-----------------------------------------------\n\r\n\r\n\r If you do not want to recieve these email notices, please login, visit settings >> preferences >> and set Allow other members/the admin to contact you by Email? to no.";
$headers = "From: $hd\n";
@mail($person_to_mail['email'],$mailsub,$mailbody,$headers);
}
}
								}
  echo "<div class='tableborder'><table width='100%'><td class='arcade1' width='100%' align='center'>Congratulations, you are the NEW Champion!</td></table></div><br /><br />";
   run_query("DELETE FROM `phpqa_leaderboard` WHERE `gamename`='$id'");
   run_query("INSERT INTO phpqa_leaderboard (username,thescore,gamename) VALUES ('$phpqa_user_cookie','$thescore','$id')"); 
   run_query("UPDATE `phpqa_games` SET `Champion_name` = '$phpqa_user_cookie',`Champion_score` = '$thescore' WHERE gameid='$id'");
   // Update the date and IP
  run_query("UPDATE `phpqa_scores` SET `ip` = '$ipa',`phpdate` = '$time' WHERE gameidname='$id' && username='$phpqa_user_cookie'");
  }
 }
 // end set check
}
}
//=================
// 				comments
//==================




	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Highscore display for Arcade.php?id=$id
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	 // select...
if (!$_COOKIE['phpqa_tourney']) {
echo "<form action='' method='POST'><input type='hidden' name='akey' value='$key'><div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1' class='highscore'><tr><td width='2%' class='headertableblock' align='center'>Username</td><td width='15%' class='headertableblock' align='center'>Score</td><td width='30%' class='headertableblock' align='center'>Comments</td><td width='30%' class='headertableblock' align='center'>Time &amp; Date</td>";

if($exist['group']=="Moderator" || $exist['group']=="Admin") {

echo "<td width='20%' class='headertableblock' align='center'>IP Address</td><td width='2%' class='headertableblock' align='center'>";
?>
<input type='checkbox' onclick="s=document.getElementsByTagName('input');for(x=0;x<s.length;x++) if (s[x].type=='checkbox') s[x].checked=this.checked" />
<?php
echo "</td>";

}

echo "</tr>";


$selectfrom=run_query("SELECT * FROM phpqa_scores WHERE gameidname='$id' ORDER BY thescore DESC,phpdate ASC");



	while($g=mysql_fetch_array($selectfrom)){ 


$parse_stamp = gmdate($datestamp, $g[5]+3600*$settings['timezone']);

$postsofsomething = $g[4];
$i=-1;
while ($i <= count($smilies)) {
$i++;
$postsofsomething = str_replace(rtrim($smilies[$i]), "<img src='emoticons/$smiliesp[$i]'>", $postsofsomething);
}

for($gx=-1;$gx<$tb;$gx++) {
if($badwords[$gx] != "") {
$postsofsomething= eregi_replace(rtrim($badwords[$gx]), "@!&^*%", $postsofsomething);
} 
}


echo "<tr><td class='arcade1' align='center'><a href='Arcade.php?action=profile&amp;user=$g[1]'>$g[1]</a></td><td class='arcade1' align='center'>$g[2]</td><td class='arcade1' width='40%' align='center'>$postsofsomething</td><td class='arcade1' width='20%' align='center'>$parse_stamp</td>";

if($exist['group']=="Moderator" || $exist['group']=="Admin") {

echo "<td width='20%' class='arcade1' align='center'><a href='?modcparea=IPscan&serv=$g[3]'>$g[3]</a></td><td width='2%' class='arcade1' align='center'><input type='checkbox' name='score_m[]' value='$g[0]'></td>";

}

echo "</tr>";

	}

if($exist['group']=="Moderator" || $exist['group']=="Admin") echo "<tr><td class='headertableblock' colspan='6'><div align=center><select name='dowhat_m'><option value='erase'>Delete Score</option><option value='comment'>Delete Comment</option>

<input type='submit' name='scoreaction' value='Go'>

</div></td></tr>";

echo "</table></div><br /></form>";
}

} elseif($_GET['cparea']) {

if ($exist['group'] == "Admin") { 
require("acp.php");
} else {
message("Only administratiors may access the admin CP");
}

} elseif($_GET['modcparea']) {
if ($exist['group'] == "Moderator" || $exist['group'] == "Admin") { 
require("acpmoderate.php");
} else {
message("Only moderators may access the ModCP");
}

} else {      				// You're on the index. OK.



	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Favorites
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if ($_GET['action']=="fav") {
vsess();
$_GET['game']=htmlspecialchars($_GET['game'], ENT_QUOTES);
$game_exist=mysql_fetch_array(run_query("SELECT id FROM phpqa_games WHERE gameid='{$_GET['game']}'"));
if($game_exist[0]) {
//Adding?
if($_GET['favtype']=="add") { 
message("Added to favorites. Refresh to see changes.");
$acct_setting[5].="{$_GET['game']},"; 
} else { 
// Removing
message("Removed game from favorites. Refresh to see changes.");
$acct_setting[5]=str_replace("{$_GET['game']},", "", $acct_setting[5]); 
}
run_query("UPDATE `phpqa_accounts` SET `settings` = '$acct_setting[0]|$acct_setting[1]|$acct_setting[2]|$acct_setting[3]|$acct_setting[4]|$acct_setting[5]' WHERE name='$phpqa_user_cookie'");
} else {
message("Game not found.");
}
}

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Game index display
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if ($_GET['action']=="search") {
?>
<div align='center'>
<div class='tableborder'><table width='100%' cellpadding='0' cellspacing='1'><tr><td width='60%' align='center' class='arcade1'>Search The Arcade<br /><br />

<form action='' method='get'>
Term: <input type='text' value='' name='search' /> <br /><br /> Search by: <br /><select size="1" name="by"><option value='game'>Game name</option><option  value='gameid'>GameID</option><option value='about'>Game desc</option><option value='Champion_name'>Champion Name</option></select>


<br /><br />In Category:<br /><select size="1" name="searchcat">
<option value='All' selected="selected">All</option>
<?php
mysql_data_seek($catquery,0);
 while ($catlist= mysql_fetch_array($catquery)) echo  "<option value='$catlist[0]'>$catlist[1]</option>"; 
?>

</select><br /><br />
<input type='submit' value='search' name='action' />
<br /><br />
</form>
</td></tr></table></div>
</div>
<br />
<?
}
	while($g=mysql_fetch_array($catquer)){ 
	// Select from the scores table....

	echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1' class='gameview'><tr><td width='5%' align='center' class='headertableblock'></td><td width='60%' align='center' class='headertableblock'>$g[1]</td><td width='20%' align='center' class='headertableblock'>Top Score</td></tr><tr><td class='arcade1' valign='top' align='center'><a href='Arcade.php?play=$g[0]'><img height='50' width='50' alt='$g[0]' border='0' src='arcade/pics/$g[0].gif' /></a><br /></td><td class='arcade1'  align='center'>$g[2]<br /><br />";

if(isset($_COOKIE['phpqa_user_c']) || $settings['allow_guests']) { echo "<a href='Arcade.php?play=$g[0]'>[Play]</a>"; } else { echo "[ Login to play ]"; }

$fav_action='';
if(isset($_COOKIE['phpqa_user_c'])) {
$fav_action="<br /><a href='Arcade.php?action=fav&game=$g[0]&favtype=add&akey=$key&fav=1'>[Add to favorites]</a>";
if($_GET['fav']) $fav_action="<br /><a href='Arcade.php?action=fav&game=$g[0]&favtype=remove&akey=$key&fav=1'>[Remove favorite]</a>";
}

echo "<div class='viewedtimes'>Played ".$g[times_played]." Time".($g[times_played]!=1?"s":"")."{$fav_action}</div></td><td class='arcade1' valign='top' align='center'><img alt='image' src='$crowndir/crown1.gif' /><br /><b>".$g[Champion_score]."</b><br />".($g[Champion_name]?"<a href='Arcade.php?action=profile&amp;user=$g[Champion_name]'>$g[Champion_name]</a>":"<b>------------</b>")."<br /><a href='Arcade.php?id=$g[0]'>View Highscores</a></td></tr></table></div><br />";

	}

	}

// =====================
// Makes pages
// You know what? I'm not even sure WHAT I just did here, 
// but it works. :)
// =====================
if($_GET['fav']) $favstuff='&fav=1';
if(!$_GET['page'])$_GET['page']=1;
$total=$arcadetotalcat/$num_pages_of;
$pagnam=explode(".",$total);
if(count($pagnam)==2) $total=$pagnam[0]+1;
$pgn_sub=$_GET['page']-2;
if($pgn_sub == 0 || $pgn_sub < 0) $pgn_sub=1;
$pag_lim=$pgn_sub*$num_pages_of;
unset($first_p);
unset($last_p);
unset($all_pag);
if($_GET['page'] > 3) $first_p="<a href='Arcade.php?cat=$cat&amp;limit=0&amp;show=$num_pages_of&amp;page=1&arcade=1{$favstuff}'>&laquo First </a>... ";
for($pag_gen=$pgn_sub;$pag_gen<$total+1;$pag_gen++) {
$pgl_real=$pag_lim-$num_pages_of;
$pgn_real=$page_gen+1;
if($_GET['page'] == "$pag_gen") { 
$all_pag.="[ $pag_gen ] ";
} else {
$all_pag.="<a href='Arcade.php?cat=$cat&amp;limit=$pgl_real&amp;show=$num_pages_of&amp;page=$pag_gen&arcade=1{$favstuff}'>$pag_gen</a> ";
}
$pag_lim+=$num_pages_of;
if($pgn+2 == $pag_gen)  {
$lastlim=$arcadetotalcat-1;
$last_p="... <a href='Arcade.php?cat=$cat&amp;limit=".$lastlim."&amp;show=".$num_pages_of."&amp;page=".$total."&arcade=1{$favstuff}'>Last &raquo</a>";
break;
}
}
$pagination='';
if($total!=1) $pagination="Pages: ($total) $first_p $all_pag $last_p"; 

if (!$_GET['action']&&!$_GET['play']&&!$_GET['id']&&!$_GET['cparea']&&!$_GET['modcparea']&&!$_GET['shoutbox']) echo "<div class='tableborder'><table width='100%' cellpadding='1' cellspacing='1'><tr><td class='arcade1' align='center'><table width='100%'><tr><td style='text-align:left;width:200px;'>$pagination</td><td style='text-align:center'>There are ".($arcadetotalcat)." games in this category</td><td style='text-align:right;width:150px;'></td></tr></table></td></tr></table></div><br />";


if($settings['enable_onlinelist']) {

			// = = = = = = = = = = = = = = = = = = 
			// 		Online List
			// = = = = = = = = = = = = = = = = = =
if($_GET['action'] != Online) {
$time=time();
if (isset($_COOKIE['phpqa_user_c'])) {

if($_GET['play']) $w="Playing Game: $g[0]|$g[gameid]";
if($id) $w="Viewing Highscores: $gameinfo[game]";
if($_GET['cparea']) $w="Using AdminCP...";
if($_GET['modcparea']) $w="Using ModCP...";
if($_GET['action']=="tournaments") $w="Viewing Tournaments";
if($_GET['action']=="settings") $w="Updating Arcade Profile...";
if($_GET['action']=="profile") $w="Viewing Member Profile";
if($_GET['action']=="leaderboards") $w="Viewing Leaderboard";
if($_GET['action']=="members") $w="Viewing Member List";
if(!$_GET['action'] && !$_GET['id'] && !$_GET['cparea'] && !$_GET['modcparea'] && !$_GET['play']) $w="Viewing Arcade Index";

$areyouthere=@mysql_fetch_array(run_query("SELECT name FROM phpqa_sessions WHERE name='$phpqa_user_cookie'"));

if(!$areyouthere) {
 
run_query("INSERT INTO phpqa_sessions (name,time,location) VALUES ('$phpqa_user_cookie','$time','$w')"); 

} else {

$areyouthere=run_query("UPDATE `phpqa_sessions` SET `time` = '$time', `location` = '$w' WHERE name='$phpqa_user_cookie'");

}


}

echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1' align='left'><fieldset class=\"search\"><legend>Users Online in the Past ".$settings['online_list_dur']." Minutes: (<a href='?action=Online&method=time'>Last Click</a>, <a href='?action=Online&method=name'>Member Name</a>)</legend><br />";

$online=run_query("SELECT * FROM phpqa_sessions ORDER by time DESC");
	while($g=mysql_fetch_array($online)){ 

$HowManyMinutes=floor($time/60)-floor($g['time']/60);

if($HowManyMinutes > $settings['online_list_dur']) { 
run_query("DELETE FROM phpqa_sessions WHERE name='$g[name]'");
} else {
$where=explode("|", $g[location]);
echo "<a href='Arcade.php?action=profile&user=$g[name]' title='$where[0] ($HowManyMinutes mins ago)'>$g[name]</a> ";  } 
}


echo "</fieldset></td></tr></table></div><br />";

}

}

?>


<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'><?php echo date("md")=="0401"?"Gilligans Arcade":"<a href='http://quickarcade.jcink.com'>PHP-Quick-Arcade</a> 3.0.22 Final"; ?> &copy; <a href='http://Jcink.com'>Jcink.com</a> - Tournaments & JS By: <a href='http://seanj.jcink.com'>SeanJ</a>.</td><td class='arcade1'><? $mtime2=explode(" ",microtime()); echo "Execution Time: ".($mtime2[1]-$mtime[1]).substr($mtime2[0]-$mtime[0],1)."</td><td class='arcade1'>Queries Used: ".count(run_query());?></td></tr></table></div></div><br />
<? ob_end_flush(); ?>
