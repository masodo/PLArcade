<?php
// -----------------------------------
// Show latest champ of leaderboard
// -----------------------------------

require("../arcade_conf.php");

$connect = @mysql_connect($host,$username,$password);
$selection = @mysql_select_db($mysqldatabase);

$scoreboardc = mysql_fetch_array(mysql_query("SELECT phpqa_accounts.name, COUNT(phpqa_leaderboard.username) AS champions FROM phpqa_accounts
LEFT JOIN phpqa_leaderboard ON phpqa_accounts.name = phpqa_leaderboard.username
GROUP BY phpqa_leaderboard.username
ORDER BY champions DESC LIMIT 0,3"));

echo  "<b>".$scoreboardc['name']."</b> is arcade leaderboard champ with: ".$scoreboardc['champions']." wins.";

?>