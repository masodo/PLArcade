<?php
// -----------------------------------
// Latest Games
// -----------------------------------

require("../arcade_conf.php");

$connect = @mysql_connect($host,$username,$password);
$selection = @mysql_select_db($mysqldatabase);

$newgames = mysql_query("SELECT gameid,game,id FROM phpqa_games ORDER by id DESC LIMIT 0,7");
	while($g=mysql_fetch_array($newgames)){ 
echo "<img height='20' width='20' src='../arcade/pics/$g[0].gif' alt='$g[1]' /><a href=\"../Arcade.php?play=$g[0]\">$g[1]</a><br />";
}


?>