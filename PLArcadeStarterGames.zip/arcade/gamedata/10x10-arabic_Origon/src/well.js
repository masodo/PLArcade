﻿//Well
var Well = function(left, top, rows, cols, padding, parentState)
{
    this.left = left;
    this.top = top;    
    this.rows = rows;
    this.cols = cols;

    this.n = rows * cols;

    //
    var grid = game.add.group();
    grid.createMultiple(this.n, 'quads', 0, false);

    var cells = new Array(rows);

    var size = grid.getAt(0).width + padding;

    var x = 0;
    var y = top + quadSize * 0.5;
    var c = 0;   

    for(var j = 0; j < rows; j++)
    {
        x = left + quadSize * 0.5;
        cells[j] = new Array(cols);
        var cj = cells[j];
        for(var i = 0; i < cols; i++)
        {
            var q = grid.getAt(c++);
            q.anchor.setTo(0.5, 0.5);
            q.x = x;
            q.y = y;
            cj[i] = q;
            x += size;
        }
        y += size;
    }

    this.grid = grid;
    this.cells = cells;        

    var w = grid.getAt(0).width;
    var h = grid.getAt(0).height;

    var width = (cells[0][cols - 1].x + w) - cells[0][0].x;
    var height = (cells[rows - 1][0].y + h) - cells[0][0].y;

    var sizeW = width / cols;
    var sizeH = height / rows;

    this.invSizeW = 1.0 / sizeW;
    this.invSizeH = 1.0 / sizeH;

    this.addingCells = [];

    this.parentState = parentState;

    this.scaleRemove = { x: 0.1, y: 0.1 };

    this.waitLines = 0;

};

//
Well.prototype = {

    tryAddShape: function(shape)
    {
        if(this.addingCells.length > 0 || shape.isNotReadyForAdding()) return false;        

        var n = shape.existsQuads;
        var wx = 0;
        var wy = 0;      

        for(var i = 0; i < n; ++i)
        {
            wx = Math.floor((shape.getQuadWorldX(i) - this.left) * this.invSizeW);
            wy = Math.floor((shape.getQuadWorldY(i) - this.top) * this.invSizeH);
            
            if(wx < 0 || wx >= this.cols || wy < 0 || wy >= this.rows || this.cells[wy][wx].exists) break;            
            
            this.addingCells.push(this.cells[wy][wx]);            
        }        

        if(this.addingCells.length === n)
        {            
            shape.beginAddingToWell(this, this.addingCells[0]);
            return true;
        }
        this.addingCells.length = 0;
        return false;
    },

    onCompliteAddingShape: function(frame)
    {
        var i = this.addingCells.length;        
        while(i--)
        {
            this.addingCells[i].frame = frame;
            this.addingCells[i].exists = true;
        }
        this.addingCells.length = 0;
        this.checkLines();
        this.parentState.onCompleteAddingShapeToWell();        
    },

    checkLines: function()
    {
        var i = 0;
        var j = this.rows;
        var row = null;

        while(j--)
        {
            row = this.cells[j];
            i = this.cols;
            while(i--) if(!row[i].exists) break;
            if(i === -1) this.removeRow(j);
        }

        j = this.cols;
        while(j--)
        {
            i = this.rows;
            while(i--) if(!this.cells[i][j].exists) break;
            if(i === -1) this.removeCol(j);
        }

    },

    removeRow: function(j)
    {
        var row = this.cells[j];
        var i = this.rows;
        var tween = null;
        while(i--)
        {
            tween = game.add.tween(row[i].scale).to(this.scaleRemove, 250, Phaser.Easing.Back.In, true, i * 50);
            tween.onComplete.add(onQuadScaleDown, row[i]);
            if(i === this.rows - 1) tween.onComplete.add(this.onComleteRemoveLine, this);
        }        
        ++this.waitLines;
        score += this.cols;
        if(sfx.line_removed) sfx.line_removed.play();
    },

    removeCol: function(j)
    {
        var tween = null;
        var i = this.cols;        
        while(i--)
        {
            tween = game.add.tween(this.cells[i][j].scale).to(this.scaleRemove, 250, Phaser.Easing.Back.In, true, i * 50);
            tween.onComplete.add(onQuadScaleDown, this.cells[i][j]);
            if(i === this.cols - 1) tween.onComplete.add(this.onComleteRemoveLine, this);
        }        
        ++this.waitLines;
        score += this.rows;
        if(sfx.line_removed) sfx.line_removed.play();
    },

    onComleteRemoveLine: function()
    {
        if(--this.waitLines === 0) this.parentState.onComleteRemoveLines();        
    },

    findShapePlace: function(state)
    {   
        var ci = 0;
        var si = 0;
        var sj = 0;
        var ci2 = 0;
        var cj2 = 0;

        var lj = this.cols - state.length + 1;
        var li = this.rows - state[0].length + 1;        

        var isNextCells = false;

        for(var cj = 0; cj < lj; ++cj)
        {            
            for(ci = 0; ci < li; ++ci)
            {                                
                for(sj = 0, cj2 = cj; sj < state.length; ++sj, ++cj2)
                {                    
                    for(si = 0, ci2 = ci; si < state[sj].length; ++si, ++ci2)
                    {
                        if(state[sj][si] === 1 && this.cells[cj2][ci2].exists)
                        {
                            isNextCells = true;
                            break;
                        }                        
                    }
                    if(isNextCells) break;
                }
                if(isNextCells) isNextCells = false;
                else return true;
            }
        }

        return false;
    },

    clear: function()
    {
        this.waitLines = 0;
        this.grid.forEach(function(item) { item.exists = false; });
    }
};

//
Well.prototype.constructor = Well;

//
function onQuadScaleDown()
{
    this.exists = false;
    this.scale.set(1);
}