//GUI
function isStock() {

    var matches = window.navigator.userAgent.match(/Android.*AppleWebKit\/([\d.]+)/);
    return matches && matches[1] < 537;
};

var gui = {

    btnTheme: null,
    btnSound: null,

    //
    createHomeButton: function(x, y, group)
    {
        var btn = game.add.button(x, y, 'gui', this.onHomeButton, this, 'btn_home', 'btn_home', 'btn_home_pressed', 'btn_home');
        btn.anchor.set(0.5);
        if(group) group.add(btn);        
    },

    onHomeButton: function()
    {
        if(playerData.score < score)
        {
            playerData.score = score;
            if(game.device.localStorage) localStorage.setItem('10x10savedata', JSON.stringify(playerData));
        }

        if(adSense) adSense.showAdvertising();

        game.state.start('menu');        
    },

    createThemeButton: function(x, y, group)
    {
        var frameNormal = playerData.theme === 0 ? 'btn_lamp_on' : 'btn_lamp_off';
        var framePressed = playerData.theme === 0 ? 'btn_lamp_on_pressed' : 'btn_lamp_off_pressed';

        var btn = game.add.button(x, y, 'gui', this.onThemeButton, this, frameNormal, frameNormal, framePressed, frameNormal);
        btn.anchor.set(0.5);
        if(group) group.add(btn);
        this.btnTheme = btn;
    },

    onThemeButton: function()
    {
        playerData.theme = 1 - playerData.theme;
        if(game.device.localStorage) localStorage.setItem('10x10savedata', JSON.stringify(playerData));

        var frameNormal = playerData.theme === 0 ? 'btn_lamp_on' : 'btn_lamp_off';
        var framePressed = playerData.theme === 0 ? 'btn_lamp_on_pressed' : 'btn_lamp_off_pressed';

        this.btnTheme.setFrames(frameNormal, frameNormal, framePressed, frameNormal);

        var state = game.state.getCurrentState();
        if(state.setTheme) state.setTheme();        
    },

    createSoundButton: function(x, y, group)
    {
        if (!isStock()){
        var btn = game.add.button(x, y, 'gui', this.onSoundButton, this, 'btn_sound_on', 'btn_sound_on', 'btn_sound_on_pressed', 'btn_sound_on');
        btn.anchor.set(0.5);
        if(group) group.add(btn);
        this.btnSound = btn;}
    },

    onSoundButton: function()
    {
        game.sound.mute = !game.sound.mute;

        var frameNormal = game.sound.mute ? 'btn_sound_off' : 'btn_sound_on';
        var framePressed = game.sound.mute ? 'btn_sound_off_pressed' : 'btn_sound_on_pressed';

        this.btnSound.setFrames(frameNormal, frameNormal, framePressed, frameNormal);
    },

    createSmallPlayButton: function(x, y, group, callback, context)
    {
        var btn = game.add.button(x, y, 'gui', callback, context, 'btn_small_play', 'btn_small_play', 'btn_small_play_pressed', 'btn_small_play');
        btn.anchor.set(0.5);
        if(group) group.add(btn);        
    },

    createScoresButton: function(x, y, group)
    {

    },

    onScoresButton: function()
    {

    },

    createBigPlayButton: function(x, y, group, callback, context)
    {
        var btn = game.add.button(x, y, 'gui', callback, context, 'btn_big_play', 'btn_big_play', 'btn_big_play_pressed', 'btn_big_play');
        btn.anchor.set(0.5);
        if(group) group.add(btn);
    },

    createMoreGamesButton: function(x, y, group)
    {
        var btn = game.add.button(x, y, 'gui', this.onMoreGamesButton, this, 'btn_moregames', 'btn_moregames', 'btn_moregames_pressed', 'btn_moregames');
        btn.anchor.set(0.5);
        if(group) group.add(btn);
    },

    onMoreGamesButton: function()
    {
        if(moregames) moregames.redirect();
    }
};