﻿//
var LoadState = {

    loadText: null,
    isReady: false,
    fontName: 'PoetsenOne',

    //
    init: function()
    {
        game.input.maxPointers = 1;
        game.stage.disableVisibilityChange = true;        

        if(!game.device.desktop)
        {
            game.scale.forceOrientation(false, true);
            game.scale.enterIncorrectOrientation.add(this.onEnterIncorrectOrientation, this);
            game.scale.leaveIncorrectOrientation.add(this.onLeaveIncorrectOrientation, this);
        }               

        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;       
        game.scale.setResizeCallback(this.gameResized, this);
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        game.scale.setScreenSize(true);        

        //
        game.load.onLoadStart.add(this.loadStart, this);
        game.load.onFileComplete.add(this.fileComplete, this);
        game.load.onLoadComplete.add(this.loadComplete, this);        
    },

    gameResized: function()
    {
        scaleFix(game.parent, game.width, game.height);
    },

    preload: function()
    {

    },

    //
    create: function()
    {        
        WebFont.load({
            custom: {
                families: [this.fontName],
                urls: ['fonts/fonts.css']
            },
            timeout: 2000
        });        
       
        game.load.spritesheet('bg_home', 'assets/bg_home.png', 640, 960, 2);
        game.load.spritesheet('bg_play', 'assets/bg_play.png', 640, 960, 2);        
        game.load.spritesheet('quads', 'assets/quads.png', 58, 58, 5);
        game.load.atlas('gui', 'assets/gui.png', 'assets/gui.json');
        game.load.json('strings', 'text/en.json');             

        if(game.device.webAudio)
            for(var i in sfx_res)
                game.load.audio(sfx_res[i], ['assets/sfx/' + sfx_res[i] + '.mp3', 'assets/sfx/' + sfx_res[i] + '.ogg']);

        //
        game.load.start();
    },  

    //
    onEnterIncorrectOrientation: function()
    {
        if(game.scale.incorrectOrientation)
        {

        }       
    },

    //
    onLeaveIncorrectOrientation: function()
    {
        
    },

    //
    loadStart: function()
    {
        this.loadText = game.add.text(game.world.centerX, game.world.centerY, '', { fill: '#ffffff' });
        this.loadText.anchor.setTo(0.5, 0.5);
    },

    //
    fileComplete: function(progress, cacheKey, success, totalLoaded, totalFiles)
    {
        this.loadText.setText(progress + "%");
    },

    //
    loadComplete: function()
    {
        //sfx
        if(game.device.webAudio)
        {
            sfx.error = game.add.audio(sfx_res.error);
            sfx.new_shapes = game.add.audio(sfx_res.new_shapes);
            sfx.new_game = game.add.audio(sfx_res.new_game);
            sfx.put_shape = game.add.audio(sfx_res.put_shape);
            sfx.line_removed = game.add.audio(sfx_res.line_removed);
        }

        //
        if(game.device.localStorage)
        {
            var saveData = localStorage.getItem('10x10savedata');
            if(saveData) playerData = JSON.parse(saveData);
        }
                
        //
        this.isReady = true;
    },

    update: function()
    {
        if(this.isReady) game.state.start('menu');
    }
};