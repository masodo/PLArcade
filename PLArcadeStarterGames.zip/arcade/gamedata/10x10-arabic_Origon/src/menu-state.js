//
var MenuState = {

    bg: null,    

    //
    create: function()
    {
        this.bg = game.add.sprite(0, 0, 'bg_home', playerData.theme);

        var label = game.add.text(320, 240, playerData.score.toString());
        label.anchor.set(0.5);
        label.font = LoadState.fontName;
        label.align = 'center';
        label.fontSize = 55;
        label.fill = '#ffffff';
        label.stroke = '#6d1701';
        label.strokeThickness = 6; 

        //
        gui.createBigPlayButton(329, 425, game.world, this.onPlayButton, this);
        gui.createScoresButton(328, 550, game.world);
        gui.createThemeButton(243, 600, game.world);
        gui.createMoreGamesButton(418, 600, game.world);

        //
        if(analytics) analytics.menu();
    },

    onPlayButton: function()
    {
        game.state.start('play');
    },

    setTheme: function()
    {
        this.bg.frame = playerData.theme;
    }
};