//

var PlayState = {    

    bg: null,
    shapeStates: null,
    placeX: [],
    placeY: 850,
    shapes: [],
    selectedShape: null,
    inputPountOffset: null,
    tweenDragOffset: null,
    existsShapes: 0,
    well: null,
    isPostFindPlaces: false,
    labelScore: null,
    labelTotalScore: null,
    displayScore: 0,
    pauseGroup: null,
    gameoverGroup: null,
    curtain: null,

    //
    create: function()
    {        
        this.bg = game.add.sprite(0, 0, 'bg_play', playerData.theme);

        this.well = new Well(21, 132, 10, 10, quadPadding, this);

        this.shapeStates = new ShapeStates();        

        this.placeX[0] = 115;
        this.placeX[1] = game.width / 2;
        this.placeX[2] = game.width - this.placeX[0];

        for(var i = 0; i < 3; i++)
        {            
            this.shapes[i] = new Shape(9, this.placeX[i], this.placeY);
            this.shapes[i].setState(this.shapeStates.getRnd());
        }

        //
        this.inputPountOffset = new Phaser.Point(0, 0);
        this.existsShapes = 3;

        //score
        var label = game.add.text(360, 80, playerData.score.toString());
        label.anchor.set(0, 0.5);
        label.font = LoadState.fontName;
        label.align = 'left';        
        label.fontSize = 40;        
        label.fill = '#ffffff';
        label.stroke = '#6d1701';
        label.strokeThickness = 6;

        this.labelTotalScore = label;

        this.displayScore = score = 0;

        label = game.add.text(280, 80, score.toString());
        label.anchor.set(1.0, 0.5);
        label.font = LoadState.fontName;
        label.align = 'right';
        label.fontSize = 40;
        label.fill = '#ffffff';
        label.stroke = '#6d1701';
        label.strokeThickness = 6;

        this.labelScore = label;

        //GUI
        //pause
        var group = game.add.group();
        gui.createHomeButton(230, 366, group);
        gui.createThemeButton(410, 366, group);
        //CheckStock

        gui.createSoundButton(230, 543, group);

        gui.createSmallPlayButton(410, 543, group, this.onPlayPause, this);

        this.pauseGroup = group;
        this.pauseGroup.visible = false;

        //game over
        group = game.add.group();

        var strings = game.cache.getJSON('strings');
        label = game.add.text(320, 200, strings.no_moves_left);
        label.anchor.set(0.5);
        label.font = LoadState.fontName;
        label.align = 'center';
        label.fontSize = 55;
        label.fill = '#fefdfc';
        label.stroke = '#050f4a';
        label.strokeThickness = 6;

        group.add(label);

        gui.createScoresButton(320, 354, group);
        gui.createBigPlayButton(322, 520, group, this.onPlayButton, this);
        gui.createHomeButton(230, 684, group);
        gui.createMoreGamesButton(410, 684, group);

        this.gameoverGroup = group;
        this.gameoverGroup.visible = false;

        //
        this.curtain = game.add.sprite(0, 0, 'gui', 'curtain');
        this.curtain.scale.set(10);
        this.curtain.visible = false;

        //
        game.input.onDown.add(this.inputOnDown, this);
        game.input.onUp.add(this.inputOnUp, this);

        //
        game.time.events.loop(75, this.updateLabelScore, this);

        //
        if(sfx.new_game) sfx.new_game.play();
    },

    inputOnDown: function(e)
    {        
        if(this.pauseGroup.visible || this.gameoverGroup.visible) return;

        var input = game.input.activePointer;

        if(input.y < 740)
        {
            if(input.y < 115 && input.x > 540) this.showPauseMenu();          
            return;
        }

        if(input.x < 214)
        {
            if(this.shapes[0].readyForDrag) this.selectedShape = this.shapes[0];
        }
        else if(input.x < 428)
        {
            if(this.shapes[1].readyForDrag) this.selectedShape = this.shapes[1];
        }
        else if(this.shapes[2].readyForDrag) this.selectedShape = this.shapes[2];

        //
        if(this.selectedShape)
        {
            this.inputPountOffset.x = this.selectedShape.parent.x - input.x;
            this.inputPountOffset.y = this.selectedShape.parent.y - input.y;            
            this.selectedShape.startDrag();
            var dragOffsetY = -this.selectedShape.hh;
            if(!game.device.desktop) dragOffsetY -= 70;
            this.tweenDragOffset = game.add.tween(this.inputPountOffset).to({ x: 0, y: dragOffsetY }, 100, Phaser.Easing.Linear.None, true);
            game.world.bringToTop(this.selectedShape.parent);
        }
    },

    inputOnUp: function(e)
    {
        if(!this.selectedShape) return;

        if(this.tweenDragOffset && this.tweenDragOffset.isRunning) this.tweenDragOffset.stop();

        if(this.well.tryAddShape(this.selectedShape))
        {
            --this.existsShapes;
            if(sfx.put_shape) sfx.put_shape.play();
        }
        else
        {
            this.selectedShape.endDrag();
            if(sfx.error) sfx.error.play();
        }
        
        this.selectedShape = null;        
    },

    generateNextShapes: function()
    {        
        this.shapes[0].reset(this.shapeStates.getRnd());
        this.shapes[1].reset(this.shapeStates.getRnd());
        this.shapes[2].reset(this.shapeStates.getRnd());
        this.existsShapes = 3;
        if(this.well.waitLines === 0) this.findPlaces();
        else this.isPostFindPlaces = true;
        if(sfx.new_shapes) sfx.new_shapes.play();
    },

    onCompleteAddingShapeToWell: function()
    {        
        if(this.existsShapes === 0) this.generateNextShapes();
        else
        {
            if(this.well.waitLines === 0) this.findPlaces();
            else this.isPostFindPlaces = true;
        }
    },

    onComleteRemoveLines: function()
    {
        if(this.isPostFindPlaces)
        {
            this.isPostFindPlaces = false;
            this.findPlaces();
        }
    },

    findPlaces: function()
    {
        var n = 0;
        var i = 3;
        while(i--)
        {
            if(this.shapes[i].isExists())
            {
                if(this.well.findShapePlace(this.shapes[i].state)) break;
                ++n;
            }
        }

        if(n === this.existsShapes) this.showGameoverMenu();
    },

    restart: function()
    {
        this.inputOnUp();
        this.well.clear();
        this.generateNextShapes();

        this.displayScore = score = 0;
        this.labelScore.text = score.toString();        
        this.labelTotalScore.text = playerData.score.toString();

        if(sfx.new_game) sfx.new_game.play();
    },

    update: function()
    {
        if(this.selectedShape)
        {
            var input = game.input.activePointer;
            this.selectedShape.setPosition(this.inputPountOffset.x + input.x, this.inputPountOffset.y + input.y);            
        }        
    },

    updateLabelScore: function()
    {        
        if(this.displayScore < score)
        {
            ++this.displayScore;            
            this.labelScore.text = this.displayScore.toString();            
        }
    },

    setTheme: function()
    {
        this.bg.frame = playerData.theme;
    },

    showPauseMenu: function()
    {
        game.world.bringToTop(this.curtain);
        game.world.bringToTop(this.pauseGroup);

        this.curtain.visible = true;
        this.pauseGroup.visible = true;
        
        this.curtain.alpha = 0.0;
        game.add.tween(this.curtain).to({ alpha: 1.0 }, 200, Phaser.Easing.Linear.None, true);

        this.pauseGroup.y = 600;
        game.add.tween(this.pauseGroup).to({ y: 0 }, 400, Phaser.Easing.Back.Out, true);
    },

    onPlayPause: function()
    {
        game.add.tween(this.curtain).to({ alpha: 0.0 }, 200, Phaser.Easing.Linear.None, true);
        game.add.tween(this.pauseGroup).to({ y: 600 }, 400, Phaser.Easing.Back.In, true).onComplete.add(this.onHidePauseMenu, this);        
    },

    onHidePauseMenu: function()
    {
        this.curtain.visible = false;
        this.pauseGroup.visible = false;
    },

    showGameoverMenu: function()
    {
        if(playerData.score < score)
        {
            playerData.score = score;
            if(game.device.localStorage) localStorage.setItem('10x10savedata', JSON.stringify(playerData));
        }

        game.world.bringToTop(this.curtain);
        game.world.bringToTop(this.gameoverGroup);

        this.curtain.visible = true;
        this.gameoverGroup.visible = true;
		
	var pathArray = window.location.pathname.split('/');
	var newpath = '';
	if (pathArray[1] && pathArray[1] != 'arcade') {
		newpath = '/' + pathArray[1];
	}

	scorepost(window.location.protocol+'//' + window.location.hostname + newpath+'/index.php?act=Arcade&do=newscore', {
            gname : '10x10-arabic_Origon',
            gscore: score
        });
        
        this.curtain.alpha = 0.0;
        game.add.tween(this.curtain).to({ alpha: 1.0 }, 200, Phaser.Easing.Linear.None, true);

        this.gameoverGroup.y = 800;
        game.add.tween(this.gameoverGroup).to({ y: 0 }, 600, Phaser.Easing.Back.Out, true);

        if(sfx.new_game) sfx.new_game.play();
        
        //
        Publisher.submitScore(R.playerData.score);
        
    },

    onPlayButton: function()
    {
        game.add.tween(this.curtain).to({ alpha: 0.0 }, 200, Phaser.Easing.Linear.None, true);
        game.add.tween(this.gameoverGroup).to({ y: 800 }, 600, Phaser.Easing.Back.In, true).onComplete.add(this.onHideGameoverMenu, this);
    },

    onHideGameoverMenu: function()
    {
        this.curtain.visible = false;
        this.gameoverGroup.visible = false;
        this.restart();
    }
};