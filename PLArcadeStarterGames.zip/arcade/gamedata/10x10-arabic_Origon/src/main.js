﻿//

var game = null;
var score = 0;

var sfx_res = {
    error: 'Error',
    new_shapes: 'New_Shapes',
    new_game: 'NewGame',
    put_shape: 'Put_stone',
    line_removed: 'Row_Removed'
};

var sfx = {};

var playerData = {
    score: 0,
    theme: 0
};

//
//window.onload = function()
function startGame()
{
    setTimeout("window.scrollTo(0, 1)", 10);
    game = new Phaser.Game(640, 960, Phaser.CANVAS, '10x10-game');

    game.state.add('load', LoadState);
    game.state.add('menu', MenuState);
    game.state.add('play', PlayState); 
   
    game.state.start('load');
}

//
window.onunload = function()
{
    if(playerData.score < score)
    {
        playerData.score = score;
        if(game.device.localStorage) localStorage.setItem('10x10savedata', JSON.stringify(playerData));
    }
}

//
var scaleFix = function(element, initialWidth, initialHeight)
{
    var self = this;

    this.viewportWidth = 0;
    this.viewportHeight = 0;

    if(typeof element === "string") element = document.getElementById(element);

    this.element = element;
    this.gameAspect = initialWidth / initialHeight;    

    // Ensure our element is going to behave:
    self.element.style.display = 'block';
    self.element.style.margin = '0';
    self.element.style.padding = '0';

    if(window.innerWidth == self.viewportWidth && window.innerHeight == self.viewportHeight) return;

    var w = window.innerWidth;
    var h = window.innerHeight;

    var windowAspect = w / h;
    var targetW = 0;
    var targetH = 0;

    targetW = w;
    targetH = h;

    if(Math.abs(windowAspect - self.gameAspect) > 0)
    {
        if(windowAspect < self.gameAspect) targetH = w / self.gameAspect;
        else targetW = h * self.gameAspect;
    }

    self.element.style.width = targetW + "px";
    self.element.style.height = targetH + "px";

    self.element.style.marginLeft = ((w - targetW) * 0.5) + "px";
    self.element.style.marginTop = ((h - targetH) * 0.5) + "px";

    self.viewportWidth = w;
    self.viewportHeight = h;
};